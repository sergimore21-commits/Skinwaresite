import { useState, useEffect } from "react"
import { ShoppingBag, Heart } from "lucide-react"

interface Notification {
  id: number
  type: "purchase" | "favorite"
  text: string
}

const notificationTexts = [
  { type: "purchase" as const, text: "María compró Sérum Vitamina C" },
  { type: "purchase" as const, text: "Juan adquirió Kit Rutina Completa" },
  { type: "purchase" as const, text: "Laura compró Gel Limpiador" },
  { type: "favorite" as const, text: "5 personas agregaron a favoritos hoy" },
  { type: "purchase" as const, text: "Pedro compró Sérum Hialurónico" },
  { type: "purchase" as const, text: "Ana realizó su primer diagnóstico" },
  { type: "favorite" as const, text: "12 compras en las últimas 2 horas" },
  { type: "purchase" as const, text: "Carlos completó su rutina Black Friday" },
]

export function SocialProofNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    let notificationId = 0

    const addNotification = () => {
      const randomText = notificationTexts[Math.floor(Math.random() * notificationTexts.length)]
      const newNotification: Notification = {
        id: notificationId++,
        type: randomText.type,
        text: randomText.text,
      }

      setNotifications((prev) => [newNotification, ...prev.slice(0, 3)])

      setTimeout(() => {
        setNotifications((prev) => prev.filter((n) => n.id !== newNotification.id))
      }, 5000)
    }

    // Primera notificación inmediata
    addNotification()

    // Nueva notificación cada 4 segundos
    const interval = setInterval(addNotification, 4000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed bottom-8 left-8 z-30 max-w-sm space-y-2 pointer-events-none">
      {notifications.map((notification) => (
        <div
          key={notification.id}
          className="animate-in slide-in-from-left-8 fade-in duration-300 bg-white rounded-lg shadow-lg border border-gray-200 p-3 flex gap-3 items-start pointer-events-auto"
        >
          <div className={`p-2 rounded-lg flex-shrink-0 ${
            notification.type === "purchase"
              ? "bg-blue-100"
              : "bg-red-100"
          }`}>
            {notification.type === "purchase" ? (
              <ShoppingBag className={`w-4 h-4 ${notification.type === "purchase" ? "text-blue-600" : "text-red-600"}`} />
            ) : (
              <Heart className="w-4 h-4 text-red-600 fill-red-600" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900 line-clamp-2">{notification.text}</p>
            <p className="text-xs text-gray-500 mt-0.5">Hace unos segundos</p>
          </div>
        </div>
      ))}
    </div>
  )
}
