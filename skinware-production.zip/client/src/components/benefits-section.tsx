import { AnimatedSection } from "@/components/animated-section"
import { CheckIcon } from "@/components/icons"

const benefits = [
  {
    title: "Fórmulas Personalizadas",
    description: "IA que adapta cada producto a tu tipo y necesidades de piel.",
  },
  {
    title: "100% Natural",
    description: "Sin químicos tóxicos ni disruptores endocrinos certificados.",
  },
  {
    title: "40% Menos Residuos",
    description: "Fabricación on-demand sin stock innecesario.",
  },
  {
    title: "Resultados en 8 Semanas",
    description: "Transformación visible de la piel comprobada clínicamente.",
  },
  {
    title: "Relación Calidad-Precio",
    description: "Lujo asequible sin intermediarios ni sobrecostos.",
  },
  {
    title: "Dermatólogo Recomendado",
    description: "Respaldado por expertos en dermatología cosmética.",
  },
]

export function BenefitsSection() {
  return (
    <section className="py-20 bg-muted">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Por qué Skinware
          </span>
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4 text-balance">
            Beneficios que transforman tu rutina
          </h2>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {benefits.map((benefit, index) => (
            <AnimatedSection key={index} delay={index * 80}>
              <div className="bg-card rounded-2xl p-6 border border-border hover:shadow-lg transition-all h-full">
                <h3 className="font-serif text-lg text-foreground mb-2">{benefit.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{benefit.description}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
