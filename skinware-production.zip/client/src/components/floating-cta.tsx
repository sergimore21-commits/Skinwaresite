import { useState, useEffect } from "react"
import { ArrowRightIcon } from "@/components/icons"
import { Link } from "wouter"

export function FloatingCTA() {
  const [isVisible, setIsVisible] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      // Mostrar después de scrollear 500px
      const showAfter = 500
      if (window.scrollY > showAfter) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
      setIsScrolled(window.scrollY > 100)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <>
      {isVisible && (
        <div className="fixed bottom-6 right-6 z-40 animate-in slide-in-from-bottom-4 duration-300">
          <Link href="/diagnostico">
            <button
              data-testid="button-floating-cta"
              className="group relative bg-gradient-to-r from-primary to-primary/80 text-primary-foreground px-6 py-4 rounded-full font-bold text-lg shadow-2xl hover:shadow-2xl hover:scale-110 transition-all duration-300 flex items-center gap-3 backdrop-blur-sm border border-primary/30"
            >
              {/* Animated pulse background */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary to-primary/80 opacity-0 group-hover:opacity-50 blur-lg group-hover:blur-xl transition-all duration-300 -z-10" />
              
              {/* Pulse ring animation */}
              <div className="absolute inset-0 rounded-full border-2 border-primary/50 animate-pulse" />
              
              <span className="relative z-10">Diagnóstico Gratis</span>
              <ArrowRightIcon className="w-5 h-5 group-hover:translate-x-1 transition-transform relative z-10" />
            </button>
          </Link>
        </div>
      )}

      {/* Mobile bottom safe area button - visible on mobile only */}
      <div className="fixed bottom-0 left-0 right-0 md:hidden z-30 bg-gradient-to-t from-background via-background to-transparent pt-4 pb-6 px-4">
        <Link href="/diagnostico">
          <button
            data-testid="button-floating-cta-mobile"
            className="w-full bg-gradient-to-r from-primary to-primary/80 text-primary-foreground py-4 rounded-full font-bold text-base shadow-2xl hover:shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <span>Hacer mi Diagnóstico</span>
            <ArrowRightIcon className="w-5 h-5" />
          </button>
        </Link>
      </div>
    </>
  )
}
