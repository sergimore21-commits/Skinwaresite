import { CheckIcon } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"

const plans = [
  {
    name: "Starter",
    price: "49",
    description: "Perfecto para comenzar",
    features: [
      "1 Diagnóstico IA",
      "1 Rutina personalizada",
      "Acceso a fórmulas básicas",
      "Soporte por email",
      "Garantía 30 días"
    ],
    highlight: false,
    cta: "Comenzar"
  },
  {
    name: "Pro",
    price: "99",
    description: "Lo más popular",
    features: [
      "Todo en Starter +",
      "4 Diagnósticos anuales",
      "Rutinas adaptadas por estación",
      "Ingredientes premium",
      "Soporte prioritario",
      "Descuentos exclusivos 15%",
      "Garantía 60 días"
    ],
    highlight: true,
    cta: "Elegir Plan"
  },
  {
    name: "Premium",
    price: "199",
    description: "Experiencia VIP",
    features: [
      "Todo en Pro +",
      "Consulta mensual con dermatólogo",
      "Fórmulas ultra-personalizadas",
      "Todos los ingredientes disponibles",
      "Envío express gratis",
      "Prioridad en nuevos lanzamientos",
      "Garantía 90 días + Reembolso"
    ],
    highlight: false,
    cta: "Contactar"
  }
]

export function PricingTable() {
  return (
    <section className="py-24 bg-gradient-to-b from-background via-secondary/5 to-background">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-20">
          <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-4">
            Planes y precios
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-foreground mb-4 text-balance">
            Elige tu plan de transformación
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Todos los planes incluyen garantía de satisfacción y soporte dedicado
          </p>
        </AnimatedSection>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto mb-12">
          {plans.map((plan, index) => (
            <AnimatedSection key={plan.name} delay={index * 100}>
              <div
                className={`relative rounded-2xl border-2 transition-all overflow-hidden group h-full flex flex-col ${
                  plan.highlight
                    ? "border-primary bg-gradient-to-br from-primary/10 via-card to-secondary/5 shadow-2xl scale-105"
                    : "border-border bg-card hover:border-primary/50"
                }`}
                data-testid={`pricing-plan-${plan.name.toLowerCase()}`}
              >
                {plan.highlight && (
                  <div className="absolute top-0 left-0 right-0 bg-primary text-white text-xs font-bold px-4 py-2 text-center uppercase tracking-wider">
                    Lo más popular
                  </div>
                )}

                <div className={`p-8 ${plan.highlight ? "pt-16" : ""}`}>
                  {/* Header */}
                  <h3 className="font-serif text-2xl font-bold text-foreground mb-2">
                    {plan.name}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-6">{plan.description}</p>

                  {/* Price */}
                  <div className="mb-8">
                    <span className="text-5xl font-serif font-bold text-primary">{plan.price}</span>
                    <span className="text-muted-foreground ml-2">EUR/mes</span>
                    <p className="text-xs text-muted-foreground mt-2">Cancelable en cualquier momento</p>
                  </div>

                  {/* Features */}
                  <div className="space-y-4 mb-8 flex-grow">
                    {plan.features.map((feature, i) => (
                      <div key={i} className="flex gap-3 items-start" data-testid={`feature-${plan.name.toLowerCase()}-${i}`}>
                        <CheckIcon className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* CTA */}
                  <Button
                    size="lg"
                    className={`w-full text-base py-6 transition-all ${
                      plan.highlight
                        ? "bg-primary hover:bg-primary/90 text-white"
                        : "border border-border hover:border-primary hover:bg-primary/5 text-foreground"
                    }`}
                    asChild
                    data-testid={`button-${plan.name.toLowerCase()}`}
                  >
                    <Link href={plan.name === "Starter" ? "/diagnostico" : plan.name === "Pro" ? "/productos" : "/contacto"}>
                      {plan.cta}
                    </Link>
                  </Button>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {/* FAQ Mini */}
        <AnimatedSection className="max-w-2xl mx-auto bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl p-8 border border-border text-center">
          <h3 className="font-serif text-xl font-bold text-foreground mb-4">¿Preguntas?</h3>
          <p className="text-muted-foreground mb-6">
            Todos nuestros planes incluyen consulta inicial personalizada y 30 días de garantía
          </p>
          <Button variant="outline" asChild>
            <Link href="/contacto">
              Hablar con un experto
            </Link>
          </Button>
        </AnimatedSection>
      </div>
    </section>
  )
}
