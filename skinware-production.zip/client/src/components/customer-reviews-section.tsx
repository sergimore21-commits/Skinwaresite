import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, Check } from "@/components/icons"
import { ThumbsUp } from "lucide-react"
import { cn } from "@/lib/utils"

interface CustomerReview {
  id: string
  author: string
  avatar: string
  product: string
  rating: number
  title: string
  content: string
  helpful: number
  verified: boolean
  date: string
  skinType: string
}

const reviews: CustomerReview[] = [
  {
    id: "1",
    author: "Ana García",
    avatar: "AG",
    product: "Sérum Vitamina C 15%",
    rating: 5,
    title: "Transformó mi piel en 3 semanas",
    content:
      "Nunca vi resultados tan rápido. Las manchas oscuras empezaron a desaparecer desde la semana 2. Mi piel está mucho más luminosa y el tono es uniforme. Es de verdad un must-have.",
    helpful: 124,
    verified: true,
    date: "Hace 5 días",
    skinType: "Normal",
  },
  {
    id: "2",
    author: "Carlos M.",
    avatar: "CM",
    product: "Gel Limpiador Purificante",
    rating: 5,
    title: "El mejor producto para piel grasa",
    content:
      "Llevo años buscando un limpiador que no resecara mi piel. Este es perfecto. Controla el brillo sin irritar. Mi piel está equilibrada por primera vez en años.",
    helpful: 89,
    verified: true,
    date: "Hace 1 semana",
    skinType: "Grasa",
  },
  {
    id: "3",
    author: "María L.",
    avatar: "ML",
    product: "Crema Nutritiva Intensa",
    rating: 5,
    title: "Salvó mi piel seca",
    content:
      "Tenía la piel tan seca que parecía agrietada. Esta crema es un milagro. Muy nutritiva pero no deja grasa. Ya voy en el segundo bote.",
    helpful: 156,
    verified: true,
    date: "Hace 10 días",
    skinType: "Seca",
  },
  {
    id: "4",
    author: "Laura S.",
    avatar: "LS",
    product: "Sérum Retinol 0.5%",
    rating: 4,
    title: "Excelente para anti-envejecimiento",
    content:
      "Notables mejoras en líneas finas. Es un producto potente, así que hay que empezar lentamente pero los resultados hablan por sí solos.",
    helpful: 67,
    verified: true,
    date: "Hace 2 semanas",
    skinType: "Mixta",
  },
]

export function CustomerReviewsSection() {
  const [sortBy, setSortBy] = useState<"helpful" | "recent" | "rating">("helpful")

  const sortedReviews = [...reviews].sort((a, b) => {
    if (sortBy === "helpful") return b.helpful - a.helpful
    if (sortBy === "rating") return b.rating - a.rating
    return 0
  })

  const averageRating = (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
  const verifiedCount = reviews.filter((r) => r.verified).length

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <AnimatedSection className="grid md:grid-cols-3 gap-8 mb-16">
          {/* Stats */}
          <div className="text-center">
            <p className="text-5xl font-serif font-bold text-primary mb-2">{averageRating}</p>
            <div className="flex justify-center gap-1 mb-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-primary text-primary" />
              ))}
            </div>
            <p className="text-muted-foreground">Puntuación promedio</p>
          </div>

          <div className="text-center">
            <p className="text-5xl font-serif font-bold text-primary mb-2">{reviews.length}</p>
            <p className="text-muted-foreground">Reseñas totales</p>
          </div>

          <div className="text-center">
            <p className="text-5xl font-serif font-bold text-primary mb-2">{verifiedCount}</p>
            <div className="flex justify-center gap-1">
              <Check className="w-4 h-4 text-green-500" />
            </div>
            <p className="text-muted-foreground">Compras verificadas</p>
          </div>
        </AnimatedSection>

        <div className="mb-8">
          <h2 className="font-serif text-3xl text-foreground mb-6">Opiniones de Clientes Verificados</h2>
          <div className="flex gap-2">
            {(["helpful", "recent", "rating"] as const).map((sort) => (
              <Button
                key={sort}
                onClick={() => setSortBy(sort)}
                className={cn(
                  "rounded-full",
                  sortBy === sort
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                )}
                data-testid={`sort-${sort}`}
              >
                {sort === "helpful" && "Más útiles"}
                {sort === "recent" && "Más recientes"}
                {sort === "rating" && "Mejor valoradas"}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid gap-6">
          {sortedReviews.map((review, index) => (
            <AnimatedSection key={review.id} direction="up" delay={index * 50}>
              <div className="border border-border rounded-xl p-6 hover:border-primary/50 hover:shadow-md transition-all" data-testid={`review-${review.id}`}>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="font-semibold text-primary">{review.avatar}</span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-foreground">{review.author}</p>
                        {review.verified && (
                          <Badge className="bg-green-500/20 text-green-700 text-xs flex gap-1">
                            <Check className="w-3 h-3" />
                            Verificado
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Piel {review.skinType} • {review.date}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                </div>

                <Badge variant="secondary" className="mb-3">
                  {review.product}
                </Badge>

                <h3 className="font-semibold text-foreground mb-2">{review.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{review.content}</p>

                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground hover:text-foreground"
                  data-testid={`helpful-${review.id}`}
                >
                  <ThumbsUp className="w-4 h-4 mr-2" />
                  Útil ({review.helpful})
                </Button>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
