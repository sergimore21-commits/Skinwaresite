import { cn } from "@/lib/utils"

export function SkeletonLoader({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "bg-muted rounded-lg animate-pulse",
        className,
      )}
    />
  )
}

export function ProductCardSkeleton() {
  return (
    <div className="bg-card rounded-2xl border border-border p-4 h-full">
      <SkeletonLoader className="aspect-square mb-4 rounded-xl" />
      <SkeletonLoader className="h-4 w-3/4 mb-2" />
      <SkeletonLoader className="h-3 w-full mb-4" />
      <div className="flex justify-between">
        <SkeletonLoader className="h-4 w-16" />
        <SkeletonLoader className="h-8 w-20 rounded-full" />
      </div>
    </div>
  )
}
