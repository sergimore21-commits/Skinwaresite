import { useState, useEffect } from "react"
import { X, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useLocation } from "wouter"

interface BlackFridayBannerProps {
  discount?: number
  productCount?: number
}

export function BlackFridayBanner({ discount = 40, productCount = 12 }: BlackFridayBannerProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  const [isActive, setIsActive] = useState(true)
  const [, setLocation] = useLocation()

  const handleComprar = () => {
    // Redirigir a la página de productos
    setLocation("/productos")
  }

  useEffect(() => {
    const calculateTimeLeft = () => {
      // Calcula el endTime como 3 días desde las 20:00h de hoy
      const now = new Date()
      const endTime = new Date(now)
      endTime.setHours(20, 0, 0, 0) // Hoy a las 20:00h
      endTime.setDate(endTime.getDate() + 3) // + 3 días

      const difference = endTime.getTime() - now.getTime()

      if (difference > 0) {
        setIsActive(true)
        const days = Math.floor(difference / (1000 * 60 * 60 * 24))
        const hours = Math.floor((difference / (1000 * 60 * 60)) % 24)
        const minutes = Math.floor((difference / 1000 / 60) % 60)
        const seconds = Math.floor((difference / 1000) % 60)
        setTimeLeft({ days, hours, minutes, seconds })
      } else {
        setIsActive(false)
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 })
      }
    }

    calculateTimeLeft()
    const timer = setInterval(calculateTimeLeft, 1000)
    return () => clearInterval(timer)
  }, [])

  if (!isVisible || !isActive) return null

  return (
    <div
      className="fixed bottom-8 right-8 z-40 animate-in fade-in slide-in-from-right-8 duration-500 max-w-sm"
      data-testid="black-friday-banner"
    >
      <div className="bg-gradient-to-br from-black via-red-950 to-black text-white rounded-2xl shadow-2xl overflow-hidden border-2 border-red-500/60 backdrop-blur-md">
        <div className="p-6 space-y-4">
          {/* Offer Header */}
          <div className="flex items-start gap-3">
            <Zap className="w-6 h-6 flex-shrink-0 animate-pulse text-red-400" />
            <div className="flex-1">
              <p className="font-black text-2xl bg-gradient-to-r from-red-400 to-red-300 bg-clip-text text-transparent">
                Black Friday
              </p>
              <p className="text-sm text-red-200 font-bold">{discount}% OFF (Temporal: 3 días)</p>
            </div>
            <button
              onClick={() => setIsVisible(false)}
              className="p-1 hover:bg-red-600/20 rounded transition-all"
              aria-label="Cerrar"
              data-testid="button-close-banner"
            >
              <X className="w-5 h-5 text-red-400" />
            </button>
          </div>

          {/* Timer */}
          <div className="bg-black/60 rounded-lg p-3 backdrop-blur-sm border border-red-500/30">
            <p className="text-xs font-black text-red-300 mb-2 uppercase tracking-widest">Termina en:</p>
            <div className="flex gap-1.5 font-mono font-black justify-center">
              <div className="flex flex-col items-center">
                <span className="bg-red-600/20 px-2 py-1 rounded text-sm text-red-300">{String(timeLeft.days).padStart(2, "0")}</span>
                <span className="text-xs text-red-300/60 mt-0.5">d</span>
              </div>
              <span className="text-sm text-red-400/60">:</span>
              <div className="flex flex-col items-center">
                <span className="bg-red-600/20 px-2 py-1 rounded text-sm text-red-300">{String(timeLeft.hours).padStart(2, "0")}</span>
                <span className="text-xs text-red-300/60 mt-0.5">h</span>
              </div>
              <span className="text-sm text-red-400/60">:</span>
              <div className="flex flex-col items-center">
                <span className="bg-red-600/20 px-2 py-1 rounded text-sm text-red-300">{String(timeLeft.minutes).padStart(2, "0")}</span>
                <span className="text-xs text-red-300/60 mt-0.5">m</span>
              </div>
              <span className="text-sm text-red-400/60">:</span>
              <div className="flex flex-col items-center">
                <span className={`bg-red-600/20 px-2 py-1 rounded text-sm ${timeLeft.seconds < 10 ? "text-red-400 animate-pulse" : "text-red-300"}`}>
                  {String(timeLeft.seconds).padStart(2, "0")}
                </span>
                <span className="text-xs text-red-300/60 mt-0.5">s</span>
              </div>
            </div>
          </div>

          {/* Products Count */}
          <div className="bg-red-600/10 rounded-lg p-2 text-center border border-red-500/20">
            <p className="text-xs text-red-200 font-bold">🔥 {productCount} productos en oferta</p>
          </div>

          {/* CTA Button */}
          <Button
            size="sm"
            onClick={handleComprar}
            className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-black text-base shadow-lg shadow-red-600/50 hover:shadow-xl hover:shadow-red-600/70 transition-all hover:scale-105 animate-pulse hover:animate-none"
            data-testid="button-black-friday"
          >
            COMPRAR AHORA 🛍️
          </Button>
        </div>
      </div>
    </div>
  )
}
