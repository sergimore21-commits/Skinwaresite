import { useState, useEffect } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { AlertCircle, Zap } from "lucide-react"

interface LimitedSlotsCounterProps {
  total?: number
  used?: number
  slotName?: string
}

export function LimitedSlotsCounter({ 
  total = 10, 
  used = 7,
  slotName = "Diagnósticos IA personalizados"
}: LimitedSlotsCounterProps) {
  const remaining = total - used
  const percentage = (used / total) * 100
  const [displayUsed, setDisplayUsed] = useState(used)

  useEffect(() => {
    // Simular cambios en tiempo real
    const interval = setInterval(() => {
      setDisplayUsed(prev => {
        if (prev >= total - 1) return 0
        return prev + Math.random() > 0.6 ? 1 : 0
      })
    }, 4000)
    return () => clearInterval(interval)
  }, [total])

  const isUrgent = percentage > 70

  return (
    <AnimatedSection className="w-full">
      <div className={`rounded-2xl p-6 border-2 backdrop-blur-sm transition-all duration-300 ${
        isUrgent 
          ? "bg-gradient-to-r from-red-50 to-orange-50 border-red-300" 
          : "bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-300"
      }`}>
        <div className="flex items-center gap-4 mb-4">
          <div className={`p-3 rounded-full ${isUrgent ? "bg-red-100" : "bg-blue-100"}`}>
            {isUrgent ? (
              <AlertCircle className={`w-6 h-6 ${isUrgent ? "text-red-600" : "text-blue-600"}`} />
            ) : (
              <Zap className={`w-6 h-6 ${isUrgent ? "text-red-600" : "text-blue-600"}`} />
            )}
          </div>
          <div className="flex-1">
            <h3 className={`font-bold text-lg ${isUrgent ? "text-red-700" : "text-blue-700"}`}>
              {slotName}
            </h3>
            <p className={`text-sm ${isUrgent ? "text-red-600" : "text-blue-600"}`}>
              {remaining <= 0 ? "❌ No hay lugares disponibles" : `⏰ Solo ${remaining} disponible${remaining === 1 ? "" : "s"} hoy`}
            </p>
          </div>
          <div className={`text-2xl font-black ${isUrgent ? "text-red-600" : "text-blue-600"}`}>
            {remaining}/{total}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-white/60 rounded-full h-3 overflow-hidden border border-white/50">
          <div
            className={`h-full transition-all duration-500 bg-gradient-to-r ${
              isUrgent
                ? "from-red-500 to-orange-500 shadow-lg shadow-red-500/50"
                : "from-blue-500 to-cyan-500 shadow-lg shadow-blue-500/50"
            }`}
            style={{ width: `${percentage}%` }}
          />
        </div>

        {/* Info Text */}
        <p className={`text-xs mt-3 font-medium ${isUrgent ? "text-red-600" : "text-blue-600"}`}>
          {percentage < 50 && "Aún hay espacios disponibles"}
          {percentage >= 50 && percentage < 80 && "Spots limitados - Apúrate"}
          {percentage >= 80 && "⚠️ Casi lleno - Queda poco tiempo"}
        </p>
      </div>
    </AnimatedSection>
  )
}
