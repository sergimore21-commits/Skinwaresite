

import { useState, useRef } from "react"
import { Link } from "wouter"
import { Clock, ArrowRight, Search, ChevronLeftIcon, ChevronRightIcon } from "@/components/icons"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { AnimatedSection } from "@/components/animated-section"
import { cn } from "@/lib/utils"
import vitaminCImg from "@assets/generated_images/vitamin_c_guide_blog_header.png"
import retinolImg from "@assets/generated_images/retinol_vs_bakuchiol_blog_header.png"
import oilySkinImg from "@assets/generated_images/oily_skin_routine_blog_header.png"
import minimalistImg from "@assets/generated_images/minimalist_skincare_blog_header.png"
import niacinamideImg from "@assets/generated_images/niacinamide_skincare_benefits_header.png"
import hyaluronicImg from "@assets/generated_images/hyaluronic_acid_myths_blog_header.png"
import sunscreenImg from "@assets/generated_images/winter_sunscreen_protection_blog_header.png"
import doubleCleansingImg from "@assets/generated_images/double_cleansing_routine_blog_header.png"

type Category = "all" | "ingredientes" | "rutinas" | "tendencias" | "consejos"

interface BlogPost {
  id: string
  slug: string
  title: string
  excerpt: string
  category: Exclude<Category, "all">
  image: string
  readTime: number
  date: string
  featured?: boolean
  relatedProduct?: { id: string; name: string }
}

const posts: BlogPost[] = [
  {
    id: "1",
    slug: "guia-completa-vitamina-c",
    title: "Guía Completa: Todo lo que necesitas saber sobre la Vitamina C",
    excerpt:
      "Descubre por qué la vitamina C es el antioxidante estrella en skincare, cómo elegir el producto adecuado y cómo incorporarlo en tu rutina diaria.",
    category: "ingredientes",
    image: vitaminCImg,
    readTime: 8,
    date: "2025-01-15",
    featured: true,
    relatedProduct: { id: "3", name: "Sérum Vitamina C 15%" },
  },
  {
    id: "2",
    slug: "retinol-vs-bakuchiol",
    title: "Retinol vs Bakuchiol: ¿Cuál es mejor para ti?",
    excerpt:
      "Analizamos las diferencias entre estos dos activos anti-edad y te ayudamos a elegir el más adecuado según tu tipo de piel.",
    category: "ingredientes",
    image: retinolImg,
    readTime: 6,
    date: "2025-01-12",
    relatedProduct: { id: "5", name: "Sérum Retinol 0.5%" },
  },
  {
    id: "3",
    slug: "rutina-perfecta-piel-grasa",
    title: "La rutina perfecta para piel grasa: paso a paso",
    excerpt:
      "Control de brillos, poros minimizados y una piel equilibrada. Te enseñamos cómo conseguirlo con los productos adecuados.",
    category: "rutinas",
    image: oilySkinImg,
    readTime: 7,
    date: "2025-01-10",
    featured: true,
  },
  {
    id: "4",
    slug: "skincare-minimalista",
    title: "Skincare Minimalista: Menos es más",
    excerpt:
      "La tendencia skinimalista llega para quedarse. Descubre cómo simplificar tu rutina sin sacrificar resultados.",
    category: "tendencias",
    image: minimalistImg,
    readTime: 5,
    date: "2025-01-08",
  },
  {
    id: "5",
    slug: "acido-hialuronico-mitos",
    title: "5 mitos sobre el Ácido Hialurónico desmentidos",
    excerpt:
      "Separamos la realidad de la ficción sobre uno de los ingredientes más populares en el mundo del skincare.",
    category: "ingredientes",
    image: hyaluronicImg,
    readTime: 4,
    date: "2025-01-05",
    relatedProduct: { id: "4", name: "Sérum Ácido Hialurónico" },
  },
  {
    id: "6",
    slug: "protector-solar-invierno",
    title: "¿Por qué usar protector solar en invierno?",
    excerpt:
      "El SPF no es solo para verano. Te explicamos por qué la protección solar es esencial los 365 días del año.",
    category: "consejos",
    image: sunscreenImg,
    readTime: 5,
    date: "2025-01-03",
  },
  {
    id: "7",
    slug: "doble-limpieza-beneficios",
    title: "Doble limpieza: El secreto coreano para una piel perfecta",
    excerpt: "Aprende la técnica de doble limpieza que ha revolucionado las rutinas de skincare en todo el mundo.",
    category: "rutinas",
    image: doubleCleansingImg,
    readTime: 6,
    date: "2024-12-28",
  },
  {
    id: "8",
    slug: "niacinamida-beneficios",
    title: "Niacinamida: El ingrediente multiusos que tu piel necesita",
    excerpt: "Desde control de sebo hasta luminosidad, descubre todos los beneficios de este ingrediente versátil.",
    category: "ingredientes",
    image: niacinamideImg,
    readTime: 7,
    date: "2024-12-25",
  },
]

const categories = [
  { value: "all", label: "Todos" },
  { value: "ingredientes", label: "Ingredientes" },
  { value: "rutinas", label: "Rutinas" },
  { value: "tendencias", label: "Tendencias" },
  { value: "consejos", label: "Consejos" },
]

export function BlogList() {
  const [search, setSearch] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<Category>("all")
  const [currentSlide, setCurrentSlide] = useState(0)
  const carouselRef = useRef<HTMLDivElement>(null)

  const filteredPosts = posts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(search.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(search.toLowerCase())
    const matchesCategory = selectedCategory === "all" || post.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const featuredPosts = posts.filter((post) => post.featured)

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % featuredPosts.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + featuredPosts.length) % featuredPosts.length)
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="bg-gradient-to-b from-primary/5 to-background py-16">
        <div className="container mx-auto px-6">
          <AnimatedSection direction="up" className="text-center max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">Blog Skinware</h1>
            <p className="text-muted-foreground text-lg">
              Consejos de expertos, guías de ingredientes y las últimas tendencias en cosmética personalizada.
            </p>
          </AnimatedSection>
        </div>
      </section>

      <div className="container mx-auto px-6 py-12">
        {/* Featured Carousel */}
        {featuredPosts.length > 0 && (
          <div className="mb-16">
            <div ref={carouselRef} className="relative rounded-3xl overflow-hidden">
              <div className="flex transition-transform duration-500" style={{ transform: `translateX(-${currentSlide * 100}%)` }}>
                {featuredPosts.map((post) => (
                  <Link key={post.id} href={`/blog/${post.slug}`} className="min-w-full block">
                    <div className="relative aspect-video bg-muted overflow-hidden group cursor-pointer">
                      <img
                        src={post.image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/50 transition-all duration-300 flex flex-col justify-end p-6 md:p-8">
                        <Badge className="w-fit mb-4 bg-primary text-primary-foreground capitalize">{post.category}</Badge>
                        <h2 className="font-serif text-2xl md:text-3xl text-white mb-2">{post.title}</h2>
                        <p className="text-white/90 text-sm md:text-base line-clamp-2">{post.excerpt}</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
              
              {featuredPosts.length > 1 && (
                <>
                  <button
                    onClick={prevSlide}
                    className="absolute left-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-white/80 hover:bg-white transition-all"
                    aria-label="Anterior"
                  >
                    <ChevronLeftIcon className="w-6 h-6 text-foreground" />
                  </button>
                  <button
                    onClick={nextSlide}
                    className="absolute right-4 top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-white/80 hover:bg-white transition-all"
                    aria-label="Siguiente"
                  >
                    <ChevronRightIcon className="w-6 h-6 text-foreground" />
                  </button>
                  
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                    {featuredPosts.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentSlide(index)}
                        className={`w-2 h-2 rounded-full transition-all ${index === currentSlide ? "bg-white w-6" : "bg-white/50"}`}
                        aria-label={`Ir a slide ${index + 1}`}
                      />
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-12">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar artículos..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-12 h-12 rounded-full border-border"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setSelectedCategory(cat.value as Category)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm transition-all",
                  selectedCategory === cat.value
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80",
                )}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Posts */}
        {selectedCategory === "all" && search === "" && (
          <section className="mb-16">
            <h2 className="font-serif text-2xl text-foreground mb-6">Destacados</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {featuredPosts.map((post, index) => (
                <AnimatedSection key={post.id} direction="up" delay={index * 100}>
                  <Link href={`/blog/${post.slug}`} className="group block h-full">
                    <article className="bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 hover:shadow-lg transition-all duration-300 h-full flex flex-col">
                      <div className="aspect-[16/9] overflow-hidden">
                        <img
                          src={post.image || "/placeholder.svg"}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                      <div className="p-6 flex flex-col flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <Badge variant="secondary" className="capitalize">
                            {post.category}
                          </Badge>
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {post.readTime} min
                          </span>
                        </div>
                        <h3 className="font-serif text-xl text-foreground group-hover:text-primary transition-colors mb-2 line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-muted-foreground text-sm line-clamp-2 mb-4 flex-1">{post.excerpt}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex flex-col gap-1">
                            <span className="text-sm text-muted-foreground">{formatDate(post.date)}</span>
                            {post.relatedProduct && (
                              <Link href={`/productos/${post.relatedProduct.id}`} className="text-xs font-semibold text-primary hover:underline">
                                → {post.relatedProduct.name}
                              </Link>
                            )}
                          </div>
                          <span className="text-primary text-sm font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                            Leer más
                            <ArrowRight className="w-4 h-4" />
                          </span>
                        </div>
                      </div>
                    </article>
                  </Link>
                </AnimatedSection>
              ))}
            </div>
          </section>
        )}

        {/* All Posts Grid */}
        <section>
          <h2 className="font-serif text-2xl text-foreground mb-6">
            {selectedCategory === "all" ? "Todos los artículos" : `Artículos de ${selectedCategory}`}
          </h2>

          {filteredPosts.length > 0 ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPosts.map((post, index) => (
                <AnimatedSection key={post.id} direction="up" delay={index * 50}>
                  <Link href={`/blog/${post.slug}`} className="group block h-full">
                    <article className="bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 hover:shadow-lg transition-all duration-300 h-full flex flex-col">
                      <div className="aspect-[16/10] overflow-hidden">
                        <img
                          src={post.image || "/placeholder.svg"}
                          alt={post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                      </div>
                      <div className="p-5 flex flex-col flex-1">
                        <div className="flex items-center gap-3 mb-3">
                          <Badge variant="secondary" className="capitalize text-xs">
                            {post.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {post.readTime} min
                          </span>
                        </div>
                        <h3 className="font-medium text-foreground group-hover:text-primary transition-colors mb-2 line-clamp-2">
                          {post.title}
                        </h3>
                        <p className="text-muted-foreground text-sm line-clamp-2 mb-4 flex-1">{post.excerpt}</p>
                        <div className="flex items-center justify-between mt-auto">
                          <span className="text-xs text-muted-foreground">{formatDate(post.date)}</span>
                          {post.relatedProduct && (
                            <Link href={`/productos/${post.relatedProduct.id}`} className="text-xs font-semibold text-primary hover:underline">
                              Ver producto
                            </Link>
                          )}
                        </div>
                      </div>
                    </article>
                  </Link>
                </AnimatedSection>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No se encontraron artículos.</p>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
