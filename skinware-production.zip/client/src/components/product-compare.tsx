import { useState } from "react"
import { Button } from "@/components/ui/button"
import { X } from "@/components/icons"

interface CompareProduct {
  id: string
  name: string
  price: number
  rating: number
}

export function ProductCompare({ onClose }: { onClose: () => void }) {
  const [selected, setSelected] = useState<CompareProduct[]>([])

  const handleAddProduct = (product: CompareProduct) => {
    if (selected.length < 3 && !selected.find(p => p.id === product.id)) {
      setSelected([...selected, product])
    }
  }

  const handleRemoveProduct = (productId: string) => {
    setSelected(selected.filter(p => p.id !== productId))
  }

  if (selected.length === 0) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Selecciona hasta 3 productos para comparar</p>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-background rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-auto">
        <div className="sticky top-0 flex justify-between items-center p-6 border-b border-border bg-background">
          <h2 className="font-serif text-2xl">Comparar Productos</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {selected.map((product) => (
              <div key={product.id} className="border border-border rounded-xl p-4">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-medium text-foreground flex-1">{product.name}</h3>
                  <button
                    onClick={() => handleRemoveProduct(product.id)}
                    className="ml-2 p-1 hover:bg-muted rounded"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-3">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Precio</p>
                    <p className="font-semibold text-lg text-primary">{product.price}€</p>
                  </div>

                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Valoración</p>
                    <p className="font-semibold">⭐ {product.rating}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-border">
            <Button onClick={onClose} className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-full">
              Cerrar Comparador
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
