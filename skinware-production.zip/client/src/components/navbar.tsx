import { Link, useLocation } from "wouter"
import { useState, useEffect } from "react"
import { MenuIcon, XIcon, Heart } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { SkinwareLogo } from "@/components/skinware-logo"
import { ThemeToggle } from "@/components/theme-toggle"
import { CartButton } from "@/components/cart-button"
import { useWishlist } from "@/components/wishlist-provider"
import { cn } from "@/lib/utils"

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [pathname] = useLocation()
  const { totalItems } = useWishlist()

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const mainNavLinks = [
    { href: "/", label: "Inicio" },
    { href: "/productos", label: "Productos" },
    { href: "/nosotros", label: "Quiénes Somos" },
    { href: "/blog", label: "Blog" },
    { href: "/contacto", label: "Contacto" },
  ]

  const userNavLinks = [
    { href: "/compartir-transformacion", label: "Mis Resultados" },
    { href: "/referral", label: "Referral" },
    { href: "/dashboard", label: "Mi Cuenta" },
  ]

  const footerNavLinks = [
    { href: "/contacto", label: "Contacto" },
  ]

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/"
    return pathname.startsWith(href)
  }

  const allNavLinks = [...mainNavLinks, ...userNavLinks, ...footerNavLinks]

  return (
    <header
      className={cn(
        "fixed top-0 left-0 right-0 z-40 transition-all duration-300",
        scrolled
          ? "bg-background/70 backdrop-blur-xl border-b border-border shadow-sm"
          : "bg-transparent border-b border-transparent",
      )}
    >
      <div className="container mx-auto px-6 py-3">
        <nav className="flex items-center justify-between gap-8">
          <Link href="/" className="flex items-center gap-2 flex-shrink-0">
            <SkinwareLogo className="w-8 h-8" />
            <span className="font-serif text-xl tracking-wide text-foreground hidden sm:inline">Skinware</span>
          </Link>

          <div className="hidden lg:flex items-center gap-8 flex-1 justify-center">
            {mainNavLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "text-sm font-medium transition-colors relative cursor-pointer whitespace-nowrap",
                  isActive(link.href) ? "text-primary" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {link.label}
                {isActive(link.href) && (
                  <span className="absolute -bottom-2 left-0 right-0 h-0.5 bg-primary rounded-full" />
                )}
              </Link>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-4">
            <ThemeToggle />
            <Button asChild variant="ghost" size="icon" className="relative">
              <Link href="/wishlist" data-testid="link-wishlist">
                <Heart className="w-5 h-5" />
                {totalItems > 0 && (
                  <span className="absolute top-0 right-0 w-5 h-5 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center font-bold">
                    {totalItems}
                  </span>
                )}
              </Link>
            </Button>
            <CartButton />
            <div className="w-px h-6 bg-border"></div>
            <Button asChild variant="outline" className="rounded-full px-6 font-semibold hover:shadow-lg transition-all duration-300" data-testid="button-login">
              <Link href="/login">Inicia Sesión</Link>
            </Button>
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg rounded-full px-6 font-semibold transition-all duration-300" data-testid="button-register">
              <Link href="/register">Crear Cuenta</Link>
            </Button>
          </div>

          <div className="flex lg:hidden items-center gap-2">
            <ThemeToggle />
            <Button asChild variant="ghost" size="icon" className="relative">
              <Link href="/wishlist" data-testid="link-wishlist-mobile">
                <Heart className="w-5 h-5" />
                {totalItems > 0 && (
                  <span className="absolute top-0 right-0 w-4 h-4 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center font-bold">
                    {totalItems}
                  </span>
                )}
              </Link>
            </Button>
            <CartButton />
            <button className="p-2" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
              {isOpen ? <XIcon className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
            </button>
          </div>
        </nav>

        {isOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-border pt-4">
            <div className="flex flex-col gap-3">
              {/* Main Links */}
              {mainNavLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "text-sm font-medium transition-colors cursor-pointer px-2 py-1.5",
                    isActive(link.href) ? "text-primary" : "text-muted-foreground hover:text-primary",
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              
              {/* Divider */}
              <div className="h-px bg-border my-1" />
              
              {/* User Links */}
              {userNavLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "text-sm font-medium transition-colors cursor-pointer px-2 py-1.5",
                    isActive(link.href) ? "text-primary" : "text-muted-foreground hover:text-primary",
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              
              {/* Divider */}
              <div className="h-px bg-border my-1" />
              
              {/* Auth Buttons */}
              <Link
                href="/login"
                className="text-sm font-medium text-muted-foreground hover:text-primary px-2 py-2"
                onClick={() => setIsOpen(false)}
              >
                Inicia Sesión
              </Link>
              <Link
                href="/register"
                className="text-sm font-medium bg-primary text-primary-foreground rounded-full px-4 py-2 text-center hover:bg-primary/90"
                onClick={() => setIsOpen(false)}
              >
                Crear Cuenta
              </Link>
              
              {/* Divider */}
              <div className="h-px bg-border my-1" />
              
              {/* Footer Links */}
              {footerNavLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "text-sm font-medium transition-colors cursor-pointer px-2 py-1.5",
                    isActive(link.href) ? "text-primary" : "text-muted-foreground hover:text-primary",
                  )}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </Link>
              ))}
              
              {/* CTA Button */}
              <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full w-full mt-2 font-semibold">
                <Link href="/diagnostico">Diagnóstico IA</Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
