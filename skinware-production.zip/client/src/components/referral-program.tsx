import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Check } from "@/components/icons"
import { Copy as CopyIcon, Gift as GiftIcon, Users as UsersIcon, TrendingUp as TrendingUpIcon } from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"

interface ReferralReward {
  referred: number
  referrerReward: string
  friendReward: string
  icon: "users" | "gift" | "trending"
}

const rewards: ReferralReward[] = [
  {
    referred: 1,
    referrerReward: "15% descuento",
    friendReward: "10% en primer compra",
    icon: "gift",
  },
  {
    referred: 3,
    referrerReward: "25% descuento + Envío Gratis",
    friendReward: "15% en primer compra",
    icon: "users",
  },
  {
    referred: 5,
    referrerReward: "40% descuento + Guía Premium",
    friendReward: "20% en primer compra",
    icon: "trending",
  },
]

export function ReferralProgram() {
  const [referralCode] = useState("SOFIA2024")
  const [copied, setCopied] = useState(false)
  const [referrals, setReferrals] = useState(2)

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode)
    setCopied(true)
    toast.success("Código copiado al portapapeles")
    setTimeout(() => setCopied(false), 2000)
  }

  const handleShareWhatsApp = () => {
    toast.success("Compartir por WhatsApp")
  }

  const handleShareEmail = () => {
    toast.success("Compartir por Email")
  }

  const handleShareCopy = () => {
    navigator.clipboard.writeText(`https://skinware.app/?ref=${referralCode}`)
    toast.success("Link de referral copiado")
  }

  const currentReward = rewards.find((r) => r.referred <= referrals) || rewards[rewards.length - 1]

  const getIcon = (icon: string) => {
    switch (icon) {
      case "users":
        return <UsersIcon className="w-6 h-6" />
      case "gift":
        return <GiftIcon className="w-6 h-6" />
      case "trending":
        return <TrendingUpIcon className="w-6 h-6" />
      default:
        return <GiftIcon className="w-6 h-6" />
    }
  }

  return (
    <section className="py-24 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">Programa de Referral</h2>
          <p className="text-lg text-muted-foreground">
            Comparte Skinware con amigos y obtén recompensas increíbles. Ambos ganamos descuentos.
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          {/* Referral Code Section */}
          <AnimatedSection direction="left">
            <div className="bg-card border border-border rounded-2xl p-8">
              <h3 className="font-serif text-2xl text-foreground mb-6">Tu código de referral</h3>

              <div className="bg-primary/10 border-2 border-primary rounded-xl p-6 mb-6">
                <p className="text-sm text-muted-foreground mb-2">Tu código único</p>
                <div className="flex items-center gap-3">
                  <code className="font-mono text-2xl font-bold text-primary">{referralCode}</code>
                  <Button
                    onClick={handleCopyCode}
                    size="icon"
                    className={cn("rounded-full transition-all", copied ? "bg-green-500" : "")}
                    data-testid="button-copy-referral"
                  >
                    {copied ? <Check className="w-5 h-5" /> : <CopyIcon className="w-5 h-5" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <p className="text-sm font-semibold text-foreground mb-2">Cómo funciona:</p>
                  <ol className="text-sm text-muted-foreground space-y-2">
                    <li className="flex gap-3">
                      <span className="font-bold text-primary min-w-fit">1.</span>
                      <span>Comparte tu código SOFIA2024 con amigos</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="font-bold text-primary min-w-fit">2.</span>
                      <span>Ellos usan el código en su primer compra</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="font-bold text-primary min-w-fit">3.</span>
                      <span>Ambos reciben descuentos automáticos</span>
                    </li>
                    <li className="flex gap-3">
                      <span className="font-bold text-primary min-w-fit">4.</span>
                      <span>Acumula referencias y desbloquea mejores recompensas</span>
                    </li>
                  </ol>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-border">
                <p className="text-sm text-muted-foreground mb-4">Comparte en redes sociales:</p>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="rounded-full flex-1" onClick={handleShareWhatsApp} data-testid="share-whatsapp">
                    WhatsApp
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full flex-1" onClick={handleShareEmail} data-testid="share-email">
                    Email
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-full flex-1" onClick={handleShareCopy} data-testid="share-copy-link">
                    Copiar link
                  </Button>
                </div>
              </div>
            </div>
          </AnimatedSection>

          {/* Progress Section */}
          <AnimatedSection direction="right">
            <div className="bg-card border border-border rounded-2xl p-8">
              <h3 className="font-serif text-2xl text-foreground mb-6">Tu progreso</h3>

              <div className="mb-8">
                <div className="flex items-end justify-between mb-3">
                  <span className="text-sm font-semibold text-foreground">Amigos referidos</span>
                  <span className="text-3xl font-bold text-primary">{referrals}</span>
                </div>
                <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
                  <div
                    className="h-full bg-primary transition-all duration-500"
                    style={{ width: `${(referrals / 5) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-2">Próximo hito: 5 referencias para el máximo descuento</p>
              </div>

              <div className="bg-primary/10 border border-primary/20 rounded-xl p-4 mb-8">
                <p className="text-sm text-muted-foreground mb-2">Tu recompensa actual:</p>
                <p className="text-lg font-bold text-primary">{currentReward.referrerReward}</p>
              </div>

              <div className="space-y-3">
                <p className="text-sm font-semibold text-foreground">Mis referencias activas:</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg text-sm">
                    <span>Carlos L. - hace 3 días</span>
                    <Badge className="bg-green-500/20 text-green-700">Completada</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg text-sm">
                    <span>Elena M. - hace 1 semana</span>
                    <Badge className="bg-green-500/20 text-green-700">Completada</Badge>
                  </div>
                  <Button variant="ghost" size="sm" className="w-full text-muted-foreground" data-testid="view-all-referrals">
                    Ver todas mis referencias
                  </Button>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>

        {/* Rewards Tiers */}
        <AnimatedSection>
          <h3 className="font-serif text-2xl text-foreground text-center mb-12">Tabla de recompensas</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {rewards.map((reward, index) => (
              <AnimatedSection
                key={index}
                direction="up"
                delay={index * 100}
                className={cn(
                  "rounded-2xl p-8 border-2 transition-all duration-300",
                  referrals >= reward.referred
                    ? "border-primary bg-primary/5 shadow-lg"
                    : "border-border bg-card hover:border-primary/50"
                )}
              >
                <div className="text-4xl mb-4 text-primary">{getIcon(reward.icon as string)}</div>
                <p className="text-sm text-muted-foreground mb-2">Referencias necesarias</p>
                <p className="font-bold text-2xl text-foreground mb-6">{reward.referred}</p>

                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-semibold text-primary uppercase tracking-wide mb-1">Para ti</p>
                    <p className="font-semibold text-foreground">{reward.referrerReward}</p>
                  </div>
                  <div className="pt-4 border-t border-border">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1">Para tu amigo</p>
                    <p className="font-semibold text-foreground">{reward.friendReward}</p>
                  </div>
                </div>

                {referrals >= reward.referred && (
                  <Badge className="mt-6 w-full justify-center bg-green-500 text-white">
                    <Check className="w-3 h-3 mr-2" />
                    Desbloqueado
                  </Badge>
                )}
              </AnimatedSection>
            ))}
          </div>
        </AnimatedSection>

        {/* FAQ */}
        <AnimatedSection direction="up" className="mt-20 max-w-2xl mx-auto">
          <h3 className="font-serif text-2xl text-foreground mb-8 text-center">Preguntas frecuentes</h3>
          <div className="space-y-4">
            <details className="border border-border rounded-lg p-4 cursor-pointer group" data-testid="faq-item-1">
              <summary className="font-semibold text-foreground flex justify-between items-center">
                ¿Cuándo recibo mis descuentos?
                <span className="transition-transform group-open:rotate-180">▼</span>
              </summary>
              <p className="text-muted-foreground mt-3 text-sm">
                Los descuentos se aplican automáticamente después de que tu amigo complete su primera compra. Tendrás acceso a ellos en tu próxima compra.
              </p>
            </details>

            <details className="border border-border rounded-lg p-4 cursor-pointer group" data-testid="faq-item-2">
              <summary className="font-semibold text-foreground flex justify-between items-center">
                ¿Hay límite de referencias?
                <span className="transition-transform group-open:rotate-180">▼</span>
              </summary>
              <p className="text-muted-foreground mt-3 text-sm">
                No, puedes referir a tantos amigos como quieras. Cada referencia exitosa acumula beneficios adicionales.
              </p>
            </details>

            <details className="border border-border rounded-lg p-4 cursor-pointer group" data-testid="faq-item-3">
              <summary className="font-semibold text-foreground flex justify-between items-center">
                ¿Se pueden combinar descuentos con otras promociones?
                <span className="transition-transform group-open:rotate-180">▼</span>
              </summary>
              <p className="text-muted-foreground mt-3 text-sm">
                Los descuentos por referral son acumulativos pero no se pueden combinar con otras promociones activas. Siempre se aplica el descuento mayor.
              </p>
            </details>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
