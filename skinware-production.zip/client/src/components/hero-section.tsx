

import { useState, useEffect } from "react"
import { Link } from "wouter"
import { ArrowRightIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"
import { BlackFridayTimerBadge } from "@/components/black-friday-timer-badge"
import skinwareProductsImg from "@assets/generated_images/skinware_cosmetics_with_black_text_branding.png"

export function HeroSection() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-secondary/30 via-background to-background" style={{ transform: `translateY(${scrollY * 0.5}px)` }} />
      <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl" style={{ transform: `translateY(${scrollY * 0.3}px)` }} />
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-3xl" style={{ transform: `translateY(${scrollY * 0.2}px)` }} />

      <div className="container mx-auto px-6 relative z-10">
        <AnimatedSection direction="up" className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium animate-pulse shadow-lg">
            <span className="w-2 h-2 rounded-full bg-primary-foreground"></span>
            15% en primera compra • 20% con SKINCARE20 • 40% Black Friday
          </div>
        </AnimatedSection>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <AnimatedSection direction="up" className="text-center lg:text-left">
            <span className="inline-block px-4 py-2 rounded-full bg-primary/10 text-primary text-xs font-bold tracking-widest uppercase mb-6 border border-primary/20">
              🔬 Diagnóstico IA + Cosmética Científica
            </span>

            <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight text-foreground text-balance mb-4">
              Tu piel merece <span className="text-primary">ciencia</span>,<br />
              no promesas
            </h1>

            <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto lg:mx-0 text-pretty font-medium leading-relaxed">
              Descubre tu tipo de piel con IA + recibe productos 100% personalizados con ingredientes científicamente probados. 
              <span className="block mt-2 text-primary font-semibold">Resultados visibles en 14 días o dinero de vuelta.</span>
            </p>

            <div className="mt-12 flex flex-col items-center gap-3 w-full lg:w-auto lg:items-start">
              <BlackFridayTimerBadge />
              <Button
                size="lg"
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-2xl hover:scale-105 rounded-full px-6 group transition-all duration-300 font-bold text-base sm:text-lg h-14 sm:h-16 w-full lg:w-auto"
              >
                <Link href="/diagnostico" className="flex items-center justify-center gap-2">
                  <span className="hidden sm:inline">Hacer mi Diagnóstico IA Gratis</span>
                  <span className="sm:hidden">Diagnóstico Gratis</span>
                  <ArrowRightIcon className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Link>
              </Button>
              <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 justify-center w-full lg:w-auto">
                <Button
                  size="lg"
                  asChild
                  className="bg-secondary/80 text-secondary-foreground hover:bg-secondary hover:shadow-lg rounded-full px-6 transition-all duration-300 font-semibold hover:scale-105 backdrop-blur-sm"
                >
                  <Link href="/test-piel">Test de Piel</Link>
                </Button>
                <Button
                  size="lg"
                  asChild
                  className="bg-secondary/80 text-secondary-foreground hover:bg-secondary hover:shadow-lg rounded-full px-6 transition-all duration-300 font-semibold hover:scale-105 backdrop-blur-sm"
                >
                  <Link href="/productos">Ver Productos</Link>
                </Button>
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                ✓ Sin datos requeridos  •  ✓ Resultado en 2 minutos  •  ✓ Confidencial
              </p>
            </div>
          </AnimatedSection>

          <AnimatedSection direction="right" delay={200} className="relative pb-8 lg:pb-0">
            <div className="aspect-[4/5] relative rounded-3xl overflow-hidden shadow-2xl">
              <img
                src={skinwareProductsImg}
                alt="Productos Skinware de cosmética de lujo"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent" />
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
