import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Link } from "wouter"

const faqCategories = [
  {
    title: "Diagnóstico IA",
    items: [
      {
        q: "¿Cómo funciona el diagnóstico IA?",
        a: "Nuestro algoritmo analiza 47 parámetros de tu piel: tipo, sensibilidad, hidratación, elasticidad, etc. En 2 minutos tienes un análisis completo y recomendaciones personalizadas."
      },
      {
        q: "¿Es preciso el diagnóstico?",
        a: "Sí, con una precisión del 98.7%. Usamos datos científicos y machine learning entrenado con dermatólogos. Puedes confiar en los resultados."
      },
      {
        q: "¿Necesito compartir datos personales?",
        a: "No. El diagnóstico funciona sin solicitar tu nombre, email o ubicación. Total privacidad."
      },
      {
        q: "¿Puedo hacer el diagnóstico varias veces?",
        a: "Sí, tantas veces como quieras. Nos encantaría saber cómo evoluciona tu piel con nuestros productos."
      }
    ]
  },
  {
    title: "Productos",
    items: [
      {
        q: "¿Todos los productos son personalizados?",
        a: "Sí, 100%. Cada fórmula se crea específicamente según tu diagnóstico IA. No hay dos productos idénticos."
      },
      {
        q: "¿Cuánto tiempo tardan los productos en hacer efecto?",
        a: "Ves primeros cambios en 7 días. Resultados completos entre 14-21 días. Garantizamos resultados en 14 días."
      },
      {
        q: "¿Son seguros para pieles sensibles?",
        a: "Totalmente. Usamos solo ingredientes naturales y científicamente probados. Libre de parabenos, sulfatos y rellenos."
      },
      {
        q: "¿Puedo combinar productos de Skinware con otras marcas?",
        a: "Sí, pero no lo recomendamos. Nuestros productos están formulados para trabajar juntos. Consulta si tienes dudas."
      }
    ]
  },
  {
    title: "Compra y Pago",
    items: [
      {
        q: "¿Qué métodos de pago aceptan?",
        a: "Tarjeta de crédito/débito, PayPal, Apple Pay y Google Pay. Todos los pagos son seguros con encriptación SSL."
      },
      {
        q: "¿Hay cargos ocultos?",
        a: "No. El precio que ves es el precio final. Incluye IVA. Sin sorpresas."
      },
      {
        q: "¿Cuál es el precio promedio?",
        a: "Nuestros productos van desde 25€ a 85€ según el tipo de fórmula. Un kit básico es ~50€."
      },
      {
        q: "¿Hay descuentos por cantidad?",
        a: "Sí. Primera compra: 15% automático. Con código SKINCARE20: 20%. Black Friday (3 días): 40% + regalos. Aplica el mejor descuento disponible."
      }
    ]
  },
  {
    title: "Envío y Entrega",
    items: [
      {
        q: "¿Cuánto cuesta el envío?",
        a: "Envío GRATIS en pedidos mayores a 50€. Envío estándar: 3,99€. Entrega en 24-48 horas."
      },
      {
        q: "¿Envían al extranjero?",
        a: "Sí, a toda Europa. Envío internacional desde 8,99€. Entrega en 3-5 días hábiles."
      },
      {
        q: "¿Puedo rastrear mi pedido?",
        a: "Claro. Recibirás un número de seguimiento por email inmediatamente. Actualización en tiempo real."
      },
      {
        q: "¿Qué pasa si mi pedido se pierde?",
        a: "Responsabilidad 100% nuestra. Te enviamos un reemplazo o reembolso sin preguntas."
      }
    ]
  },
  {
    title: "Garantía y Devoluciones",
    items: [
      {
        q: "¿Cuál es tu garantía?",
        a: "14 días dinero de vuelta. Si no ves resultados, devolvemos tu dinero al 100%. Sin preguntas."
      },
      {
        q: "¿Cómo solicito una devolución?",
        a: "Email a support@skinware.es con tu número de pedido. Te enviaremos etiqueta de envío prepagada."
      },
      {
        q: "¿Tengo que devolver el empaque original?",
        a: "No es obligatorio. Solo empaca el producto de forma segura. El estado del empaque no importa."
      },
      {
        q: "¿Cuánto tardan en procesar mi reembolso?",
        a: "3-5 días hábiles desde que recibimos tu devolución. Tiempo total: 7-10 días."
      }
    ]
  }
]

export function FAQExpanded() {
  const [openCategory, setOpenCategory] = useState(0)
  const [openItems, setOpenItems] = useState<{ [key: string]: boolean }>({})

  const toggleItem = (key: string) => {
    setOpenItems(prev => ({ ...prev, [key]: !prev[key] }))
  }

  return (
    <section className="py-20 bg-gradient-to-b from-secondary/5 to-background">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">
            Preguntas Frecuentes
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Resolvemos tus dudas. Si no encuentras la respuesta, contacta a nuestro equipo.
          </p>
        </AnimatedSection>

        <div className="max-w-4xl mx-auto">
          {/* Category Tabs */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-12">
            {faqCategories.map((category, index) => (
              <button
                key={index}
                onClick={() => setOpenCategory(index)}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                  openCategory === index
                    ? "bg-primary text-primary-foreground shadow-lg"
                    : "bg-card border border-border hover:border-primary/50 text-foreground"
                }`}
                data-testid={`faq-tab-${index}`}
              >
                {category.title}
              </button>
            ))}
          </div>

          {/* FAQ Items */}
          <div className="space-y-3">
            {faqCategories[openCategory].items.map((item, index) => {
              const itemKey = `${openCategory}-${index}`
              return (
                <AnimatedSection key={itemKey} delay={index * 50}>
                  <details
                    className="group bg-card rounded-lg border border-border hover:border-primary/50 transition-all overflow-hidden"
                    open={openItems[itemKey]}
                    onToggle={() => toggleItem(itemKey)}
                  >
                    <summary className="flex items-center justify-between p-5 cursor-pointer hover:bg-muted/30 transition-colors">
                      <h3 className="font-semibold text-foreground text-left pr-4">{item.q}</h3>
                      <ChevronDown className="w-5 h-5 text-primary group-open:rotate-180 transition-transform flex-shrink-0" />
                    </summary>
                    <div className="px-5 pb-4 pt-0 text-muted-foreground border-t border-border text-sm leading-relaxed">
                      {item.a}
                    </div>
                  </details>
                </AnimatedSection>
              )
            })}
          </div>

          {/* Still Have Questions */}
          <AnimatedSection className="text-center mt-16 p-8 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl border border-primary/20">
            <h3 className="font-serif text-2xl text-foreground mb-3">¿Sigue sin resolver tu duda?</h3>
            <p className="text-muted-foreground mb-6">
              Nuestro equipo de atención al cliente está listo para ayudarte
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                size="lg"
                asChild
                className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full"
              >
                <Link href="/contacto">
                  Contactar Soporte
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="rounded-full"
              >
                <a href="mailto:support@skinware.es">
                  support@skinware.es
                </a>
              </Button>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  )
}
