import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Upload, Check, Image as ImageIcon } from "lucide-react"
import { toast } from "sonner"

interface UploadedImages {
  before?: File
  after?: File
}

export function BeforeAfterUpload() {
  const [images, setImages] = useState<UploadedImages>({})
  const [daysToResults, setDaysToResults] = useState(14)
  const [testimonial, setTestimonial] = useState("")
  const [productUsed, setProductUsed] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleImageUpload = (type: "before" | "after", file: File) => {
    if (file.type.startsWith("image/")) {
      setImages({ ...images, [type]: file })
      toast.success(`Imagen ${type === "before" ? "ANTES" : "DESPUÉS"} cargada`)
    } else {
      toast.error("Solo se permiten archivos de imagen")
    }
  }

  const handleSubmit = async () => {
    if (!images.before || !images.after) {
      toast.error("Por favor carga ambas imágenes")
      return
    }

    if (!testimonial.trim()) {
      toast.error("Por favor escribe tu testimonio")
      return
    }

    setIsSubmitting(true)
    // Simulamos envío
    setTimeout(() => {
      toast.success("Transformación compartida! Aparecerá en nuestra galería pronto")
      setImages({})
      setTestimonial("")
      setProductUsed("")
      setDaysToResults(14)
      setIsSubmitting(false)
    }, 2000)
  }

  return (
    <AnimatedSection className="bg-card rounded-2xl border border-border p-8">
      <h3 className="font-serif text-2xl text-foreground mb-2">Comparte tu Transformación</h3>
      <p className="text-muted-foreground mb-8">
        Muestra tus resultados y aparece en nuestra galería de clientes verificados
      </p>

      <div className="grid md:grid-cols-2 gap-8 mb-8">
        {/* Before Image */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-3">Foto ANTES</label>
          <div className="relative">
            {images.before ? (
              <div className="w-full aspect-square rounded-xl overflow-hidden bg-muted flex items-center justify-center">
                <div className="text-center">
                  <Check className="w-12 h-12 text-green-500 mx-auto mb-2" />
                  <p className="text-sm text-foreground">{images.before.name}</p>
                </div>
              </div>
            ) : (
              <div className="w-full aspect-square rounded-xl border-2 border-dashed border-border hover:border-primary transition-colors cursor-pointer bg-muted/50 flex flex-col items-center justify-center gap-3">
                <ImageIcon className="w-12 h-12 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Clic para cargar imagen</p>
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => e.target.files?.[0] && handleImageUpload("before", e.target.files[0])}
              className="absolute inset-0 opacity-0 cursor-pointer"
              data-testid="input-before-image"
            />
          </div>
        </div>

        {/* After Image */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-3">Foto DESPUÉS</label>
          <div className="relative">
            {images.after ? (
              <div className="w-full aspect-square rounded-xl overflow-hidden bg-muted flex items-center justify-center">
                <div className="text-center">
                  <Check className="w-12 h-12 text-green-500 mx-auto mb-2" />
                  <p className="text-sm text-foreground">{images.after.name}</p>
                </div>
              </div>
            ) : (
              <div className="w-full aspect-square rounded-xl border-2 border-dashed border-border hover:border-primary transition-colors cursor-pointer bg-muted/50 flex flex-col items-center justify-center gap-3">
                <ImageIcon className="w-12 h-12 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">Clic para cargar imagen</p>
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => e.target.files?.[0] && handleImageUpload("after", e.target.files[0])}
              className="absolute inset-0 opacity-0 cursor-pointer"
              data-testid="input-after-image"
            />
          </div>
        </div>
      </div>

      {/* Form Fields */}
      <div className="space-y-6 mb-8">
        <div>
          <label className="block text-sm font-semibold text-foreground mb-3">¿Cuántos días de resultados?</label>
          <input
            type="number"
            min="1"
            max="90"
            value={daysToResults}
            onChange={(e) => setDaysToResults(parseInt(e.target.value))}
            className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            data-testid="input-days"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-foreground mb-3">Producto utilizado</label>
          <input
            type="text"
            value={productUsed}
            onChange={(e) => setProductUsed(e.target.value)}
            placeholder="Ej: Sérum Vitamina C + Crema Hidratante"
            className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            data-testid="input-product"
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-foreground mb-3">Tu testimonio</label>
          <textarea
            value={testimonial}
            onChange={(e) => setTestimonial(e.target.value)}
            placeholder="Cuenta tu experiencia... (mínimo 30 caracteres)"
            className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary min-h-24 resize-none"
            data-testid="textarea-testimonial"
          />
          <p className="text-xs text-muted-foreground mt-2">{testimonial.length} caracteres</p>
        </div>
      </div>

      {/* Info Box */}
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-4 mb-8">
        <p className="text-sm text-foreground">
          Al compartir, aceptas que tu transformación aparezca en nuestra galería pública con tu nombre y foto.
          Las imágenes se verifican antes de publicarse.
        </p>
      </div>

      {/* Submit Button */}
      <Button
        onClick={handleSubmit}
        disabled={isSubmitting || !images.before || !images.after}
        className="w-full rounded-full gap-2 h-12"
        data-testid="button-submit-transformation"
      >
        {isSubmitting ? (
          <>Enviando...</>
        ) : (
          <>
            <Upload className="w-4 h-4" />
            Compartir Transformación
          </>
        )}
      </Button>
    </AnimatedSection>
  )
}
