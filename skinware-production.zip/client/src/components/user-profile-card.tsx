import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Edit, LogOut } from "lucide-react"

interface UserProfileCardProps {
  name: string
  email: string
  avatar?: string
  tier: "Bronze" | "Silver" | "Gold"
  joinDate: string
}

export function UserProfileCard({ name, email, avatar, tier, joinDate }: UserProfileCardProps) {
  const tierColors = {
    Bronze: "bg-amber-500/20 text-amber-700",
    Silver: "bg-slate-400/20 text-slate-700",
    Gold: "bg-yellow-500/20 text-yellow-700",
  }

  return (
    <AnimatedSection>
      <div className="bg-card rounded-2xl border border-border p-8">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
              <span className="text-3xl font-bold text-primary">{name.charAt(0)}</span>
            </div>
            <div>
              <h2 className="text-2xl font-serif text-foreground mb-1">{name}</h2>
              <p className="text-sm text-muted-foreground">{email}</p>
              <Badge className={`${tierColors[tier]} mt-2`}>Nivel {tier}</Badge>
            </div>
          </div>
          <Button variant="ghost" size="icon">
            <Edit className="w-5 h-5" />
          </Button>
        </div>

        <div className="border-t border-border pt-6">
          <p className="text-sm text-muted-foreground mb-4">Cliente desde {joinDate}</p>
          <Button className="w-full rounded-full" variant="outline" data-testid="button-edit-profile">
            Editar Perfil
          </Button>
          <Button className="w-full rounded-full mt-2" variant="ghost" data-testid="button-logout">
            <LogOut className="w-4 h-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </div>
    </AnimatedSection>
  )
}
