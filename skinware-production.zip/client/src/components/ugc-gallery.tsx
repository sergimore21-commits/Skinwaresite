import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, Check } from "@/components/icons"
import { cn } from "@/lib/utils"
import akneBefore from "@assets/generated_images/before:_young_latina_with_severe_acne_breakout.png"
import akneAfter from "@assets/generated_images/after:_same_latina_woman_clear_radiant_skin.png"
import dryBefore from "@assets/generated_images/before:_asian_woman_very_dry_dehydrated_skin.png"
import dryAfter from "@assets/generated_images/after:_same_asian_woman_hydrated_glowing_skin.png"
import spotsBefore from "@assets/generated_images/before:_caucasian_woman_with_hyperpigmentation_spots.png"
import spotsAfter from "@assets/generated_images/after:_same_caucasian_woman_clear_even_skin.png"
import rednesssBefore from "@assets/generated_images/before:_african_woman_red_inflamed_sensitive_skin.png"
import rednessAfter from "@assets/generated_images/after:_same_african_woman_calm_clear_skin.png"

interface Transformation {
  id: string
  before: string
  after: string
  name: string
  skinType: string
  concern: string
  daysToResults: number
  rating: number
  testimonial: string
  product: string
  verified: boolean
}

const transformations: Transformation[] = [
  {
    id: "1",
    before: akneBefore,
    after: akneAfter,
    name: "Sofia M.",
    skinType: "Grasa",
    concern: "Acné",
    daysToResults: 14,
    rating: 5,
    testimonial: "En solo 2 semanas vi una diferencia notable. Los granos disminuyeron y mi piel está más controlada.",
    product: "Gel Limpiador + Sérum Niacinamida",
    verified: true,
  },
  {
    id: "2",
    before: dryBefore,
    after: dryAfter,
    name: "Laura H.",
    skinType: "Seca",
    concern: "Deshidratación",
    daysToResults: 21,
    rating: 5,
    testimonial: "Mi piel seca finalmente encontró lo que necesitaba. Mucho más hidratada y suave.",
    product: "Leche Limpiadora + Crema Nutritiva",
    verified: true,
  },
  {
    id: "3",
    before: spotsBefore,
    after: spotsAfter,
    name: "María R.",
    skinType: "Mixta",
    concern: "Manchas",
    daysToResults: 30,
    rating: 5,
    testimonial: "Las manchas de acné disminuyeron significativamente. Mi piel brilla más y está más uniforme.",
    product: "Sérum Vitamina C + Protector Solar",
    verified: true,
  },
  {
    id: "4",
    before: rednesssBefore,
    after: rednessAfter,
    name: "Andrea P.",
    skinType: "Sensible",
    concern: "Enrojecimiento",
    daysToResults: 28,
    rating: 4,
    testimonial: "Mi piel sensible finalmente tiene una rutina que tolera bien. Menos irritada.",
    product: "Exfoliante Enzimático + Crema Hidratante",
    verified: true,
  },
]

type ConcernFilter = "all" | "acné" | "deshidratación" | "manchas" | "enrojecimiento"

export function UGCGallery() {
  const [selectedConcern, setSelectedConcern] = useState<ConcernFilter>("all")

  const concerns = [
    { value: "all" as const, label: "Todos" },
    { value: "acné" as const, label: "Acné" },
    { value: "deshidratación" as const, label: "Deshidratación" },
    { value: "manchas" as const, label: "Manchas" },
    { value: "enrojecimiento" as const, label: "Enrojecimiento" },
  ]

  const filteredTransformations = transformations.filter(
    (t) => selectedConcern === "all" || t.concern.toLowerCase() === selectedConcern
  )

  return (
    <section className="py-24 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">Resultados Reales de Clientes</h2>
          <p className="text-lg text-muted-foreground">
            Transformaciones verificadas de personas como tú que confían en Skinware
          </p>
        </AnimatedSection>

        <div className="flex flex-wrap gap-2 justify-center mb-12">
          {concerns.map((concern) => (
            <Button
              key={concern.value}
              onClick={() => setSelectedConcern(concern.value)}
              className={cn(
                "rounded-full transition-all",
                selectedConcern === concern.value
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              )}
              data-testid={`filter-concern-${concern.value}`}
            >
              {concern.label}
            </Button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {filteredTransformations.map((transformation, index) => (
            <AnimatedSection key={transformation.id} direction="up" delay={index * 100}>
              <div className="bg-card rounded-2xl border border-border overflow-hidden hover:shadow-lg transition-all duration-300 group" data-testid={`ugc-card-${transformation.id}`}>
                {/* Before/After Side by Side */}
                <div className="grid grid-cols-2 gap-0 relative">
                  {/* Before */}
                  <div className="relative">
                    <img
                      src={transformation.before}
                      alt="Antes"
                      className="w-full h-60 object-cover"
                    />
                    <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs font-bold px-2.5 py-1 rounded-full">
                      ANTES
                    </div>
                  </div>
                  
                  {/* After */}
                  <div className="relative">
                    <img
                      src={transformation.after}
                      alt="Después"
                      className="w-full h-60 object-cover"
                    />
                    <div className="absolute bottom-2 right-2 bg-primary/85 text-white text-xs font-bold px-2.5 py-1 rounded-full">
                      DESPUÉS
                    </div>
                  </div>

                  {/* Badges */}
                  <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground z-10 text-xs">
                    {transformation.daysToResults} días
                  </Badge>

                  {transformation.verified && (
                    <Badge className="absolute top-3 right-3 bg-green-500 text-white flex gap-1 z-10 text-xs">
                      <Check className="w-3 h-3" />
                      Verificado
                    </Badge>
                  )}
                </div>

                {/* Content */}
                <div className="p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-foreground">{transformation.name}</p>
                      <p className="text-xs text-muted-foreground">
                        Piel {transformation.skinType} • {transformation.concern}
                      </p>
                    </div>
                    <div className="flex gap-1">
                      {[...Array(transformation.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                      ))}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground mb-4 italic">"{transformation.testimonial}"</p>

                  <p className="text-xs font-medium text-primary mb-0">Usó: {transformation.product}</p>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {filteredTransformations.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No hay transformaciones para esta categoría aún.</p>
          </div>
        )}

        <AnimatedSection direction="up" className="mt-16 text-center">
          <p className="text-muted-foreground mb-6">
            ¿Tienes resultados que quieres compartir? Sube tus fotos antes/después y aparece aquí
          </p>
          <Button size="lg" className="rounded-full">
            Compartir mi transformación
          </Button>
        </AnimatedSection>
      </div>
    </section>
  )
}
