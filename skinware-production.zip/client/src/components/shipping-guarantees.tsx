

import { AnimatedSection } from "@/components/animated-section"
import { Truck, Shield, RotateCcw, Award, Clock, CheckIcon, LightbulbIcon, HeartIcon, LeafIcon } from "@/components/icons"

const guarantees = [
  {
    icon: Truck,
    title: "Envío Gratis +40€",
    description: "Envíos gratuitos en pedidos superiores a 40€. Entrega en 2-4 días laborables.",
  },
  {
    icon: Shield,
    title: "Garantía 30 días",
    description: "Si no estás satisfecho, te devolvemos el dinero. Sin preguntas.",
  },
  {
    icon: RotateCcw,
    title: "Devolución Fácil",
    description: "Proceso de devolución simple y gratuito. Te enviamos la etiqueta.",
  },
  {
    icon: Award,
    title: "Calidad Premium",
    description: "Ingredientes de alta eficacia respaldados por ciencia.",
  },
  {
    icon: Clock,
    title: "Atención 24/48h",
    description: "Respondemos todas tus consultas en menos de 48 horas.",
  },
]

const trust = [
  { icon: CheckIcon, label: "Dermatológicamente testado" },
  { icon: LeafIcon, label: "100% vegano" },
  { icon: LightbulbIcon, label: "Científicamente testado" },
  { icon: HeartIcon, label: "Certificado cruelty-free" },
]

export function ShippingGuarantees() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="text-center mb-12">
          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">Compra con confianza</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Tu satisfacción es nuestra prioridad. Por eso ofrecemos las mejores garantías del mercado.
          </p>
        </AnimatedSection>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {guarantees.map((guarantee, index) => (
            <AnimatedSection key={guarantee.title} direction="up" delay={index * 50}>
              <div className="bg-card rounded-2xl border border-border p-6 h-full hover:border-primary/50 hover:shadow-lg transition-all duration-300 group">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <guarantee.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-medium text-foreground mb-2">{guarantee.title}</h3>
                <p className="text-sm text-muted-foreground">{guarantee.description}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {/* Trust Badges */}
        <AnimatedSection direction="up" className="text-center mb-8">
          <h3 className="font-serif text-2xl text-foreground">Certificaciones y garantías de producto</h3>
        </AnimatedSection>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {trust.map((item, index) => (
            <AnimatedSection key={item.label} direction="up" delay={index * 100}>
              <div className="group bg-card p-6 rounded-2xl border border-border hover:border-primary/50 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 h-full flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 group-hover:from-primary/40 group-hover:to-primary/20 transition-all duration-300 group-hover:scale-110">
                  <item.icon className="h-8 w-8 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
                <p className="text-sm font-medium text-foreground text-center group-hover:text-primary transition-colors">{item.label}</p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  )
}
