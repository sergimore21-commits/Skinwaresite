import { useState, useEffect } from "react"
import { Users } from "lucide-react"

interface LiveViewersBadgeProps {
  productId: string
  initialCount?: number
}

export function LiveViewersBadge({ productId, initialCount = 0 }: LiveViewersBadgeProps) {
  const [viewers, setViewers] = useState(initialCount)

  useEffect(() => {
    // Simulamos cambios aleatorios de visitantes cada 3-8 segundos
    const interval = setInterval(() => {
      setViewers((prev) => {
        const change = Math.floor(Math.random() * 5) - 2 // -2 a +2
        return Math.max(1, prev + change)
      })
    }, Math.random() * 5000 + 3000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div
      className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/30"
      data-testid={`live-viewers-${productId}`}
    >
      <div className="flex items-center gap-1">
        <Users className="w-4 h-4 text-primary" />
        <span className="text-xs font-semibold text-primary">{viewers} viendo ahora</span>
      </div>
      <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
    </div>
  )
}
