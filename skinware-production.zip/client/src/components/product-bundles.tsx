import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Package, ShoppingCart, Star } from "lucide-react"
import { cn } from "@/lib/utils"
import { useCart } from "@/components/cart-provider"
import { BlackFridayTimerBadge } from "@/components/black-friday-timer-badge"
import { toast } from "sonner"

interface BundleProduct {
  id: string
  name: string
  price: number
  image: string
}

interface Bundle {
  id: string
  name: string
  description: string
  products: BundleProduct[]
  originalPrice: number
  bundlePrice: number
  savings: number
  savingsPercent: number
  badge?: string
  rating?: number
  reviews?: number
}

const bundles: Bundle[] = [
  {
    id: "bundle-1",
    name: "Rutina Básica Completa",
    description: "Limpieza, tratamiento e hidratación",
    products: [
      { id: "p1", name: "Gel Limpiador", price: 28, image: "/placeholder.svg" },
      { id: "p2", name: "Sérum Vitamina C", price: 58, image: "/placeholder.svg" },
      { id: "p3", name: "Crema Hidratante", price: 45, image: "/placeholder.svg" },
    ],
    originalPrice: 131,
    bundlePrice: 98,
    savings: 33,
    savingsPercent: 25,
    badge: "POPULAR",
    rating: 4.8,
    reviews: 342,
  },
  {
    id: "bundle-2",
    name: "Tratamiento Anti-Edad",
    description: "Para los que buscan resultados premium",
    products: [
      { id: "p4", name: "Sérum Retinol", price: 48, image: "/placeholder.svg" },
      { id: "p5", name: "Exfoliante Enzimático", price: 35, image: "/placeholder.svg" },
      { id: "p6", name: "Crema Nutritiva", price: 52, image: "/placeholder.svg" },
      { id: "p7", name: "Protector Solar 50+", price: 32, image: "/placeholder.svg" },
    ],
    originalPrice: 167,
    bundlePrice: 119,
    savings: 48,
    savingsPercent: 29,
    badge: "OFERTA",
    rating: 4.9,
    reviews: 289,
  },
  {
    id: "bundle-3",
    name: "Kit de Viaje",
    description: "Tamaños prácticos para llevar",
    products: [
      { id: "p8", name: "Gel Limpiador (mini)", price: 12, image: "/placeholder.svg" },
      { id: "p9", name: "Sérum (mini)", price: 20, image: "/placeholder.svg" },
      { id: "p10", name: "Crema (mini)", price: 15, image: "/placeholder.svg" },
    ],
    originalPrice: 47,
    bundlePrice: 32,
    savings: 15,
    savingsPercent: 32,
    rating: 4.7,
    reviews: 156,
  },
]

export function ProductBundles() {
  const { addItem, setIsOpen } = useCart()

  const handleAddBundle = (bundle: Bundle) => {
    // Agregar el bundle como un item del carrito
    addItem({
      id: bundle.id,
      name: bundle.name,
      price: bundle.bundlePrice,
      image: "/placeholder.svg",
      quantity: 1,
    })
    
    // Abrir el carrito automáticamente
    setIsOpen(true)
    
    // Mostrar confirmación
    toast.success(`${bundle.name} agregado al carrito`, {
      description: `Total: ${bundle.bundlePrice}€`,
    })
  }

  return (
    <section className="py-24 bg-gradient-to-b from-background to-primary/5">
      <div className="container mx-auto px-6">
        <AnimatedSection className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex justify-center mb-6">
            <BlackFridayTimerBadge />
          </div>
          <h2 className="font-serif text-4xl md:text-5xl text-foreground mb-4">Packs Especiales</h2>
          <p className="text-lg text-muted-foreground">
            Ahorra más comprando productos seleccionados juntos. Descuentos de hasta 30%
          </p>
        </AnimatedSection>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {bundles.map((bundle, index) => (
            <AnimatedSection key={bundle.id} direction="up" delay={index * 100}>
              <div
                className={cn(
                  "rounded-2xl border-2 transition-all hover:shadow-2xl h-full flex flex-col hover:scale-105",
                  bundle.badge === "POPULAR"
                    ? "border-primary bg-primary/5 shadow-lg hover:shadow-primary/20"
                    : "border-border bg-card hover:border-primary/50"
                )}
                data-testid={`bundle-${bundle.id}`}
              >
                <div className="p-6 flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-serif text-xl text-foreground mb-1">{bundle.name}</h3>
                      <p className="text-sm text-muted-foreground">{bundle.description}</p>
                    </div>
                    {bundle.badge && (
                      <Badge className="bg-primary text-primary-foreground whitespace-nowrap ml-2">
                        {bundle.badge}
                      </Badge>
                    )}
                  </div>

                  {/* Products List */}
                  <div className="my-6 space-y-2 pb-6 border-b border-border">
                    {bundle.products.map((product) => (
                      <div key={product.id} className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">{product.name}</span>
                        <span className="font-semibold text-foreground">{product.price}€</span>
                      </div>
                    ))}
                  </div>

                  {/* Rating */}
                  {bundle.rating && (
                    <div className="flex items-center gap-1.5 pb-4 border-b border-border">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${i < Math.floor(bundle.rating!) ? "fill-primary text-primary" : "text-gray-300"}`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground font-semibold">
                        {bundle.rating} ({bundle.reviews} reseñas)
                      </span>
                    </div>
                  )}

                  {/* Pricing */}
                  <div className="space-y-3">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Precio original</p>
                      <p className="text-sm text-muted-foreground line-through">{bundle.originalPrice}€</p>
                    </div>

                    <div className="bg-primary/15 rounded-lg p-4 border border-primary/20">
                      <p className="text-xs text-primary font-semibold mb-2 uppercase tracking-wider">Precio especial</p>
                      <div className="flex items-baseline justify-between">
                        <span className="text-4xl font-bold text-primary">{bundle.bundlePrice}€</span>
                        <span className="text-sm font-bold text-green-600 bg-green-500/10 px-2 py-1 rounded-full">
                          Ahorro {bundle.savingsPercent}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-6 pt-0">
                  <Button 
                    onClick={() => handleAddBundle(bundle)}
                    className="w-full rounded-full font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105 group bg-primary hover:bg-primary/90" 
                    data-testid={`button-add-bundle-${bundle.id}`}
                  >
                    <ShoppingCart className="w-4 h-4 mr-2 group-hover:scale-110 transition-transform" />
                    Añadir al Carrito
                  </Button>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>

        {/* Info Section */}
        <AnimatedSection className="bg-card rounded-2xl border border-border p-8 text-center max-w-2xl mx-auto">
          <h3 className="font-serif text-2xl text-foreground mb-3">¿Por qué elegir un pack?</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <p className="text-2xl font-bold text-primary mb-2">30%</p>
              <p className="text-sm text-muted-foreground">Ahorro máximo</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary mb-2">100%</p>
              <p className="text-sm text-muted-foreground">Rutina completa</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary mb-2">Envío</p>
              <p className="text-sm text-muted-foreground">Gratis siempre</p>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
