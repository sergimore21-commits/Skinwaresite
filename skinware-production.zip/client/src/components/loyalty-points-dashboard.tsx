import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Zap, Gift } from "lucide-react"

interface LoyaltyPointsDashboardProps {
  currentPoints: number
  totalPointsEarned: number
  nextMilestone: number
  tier: "Bronze" | "Silver" | "Gold"
}

export function LoyaltyPointsDashboard({
  currentPoints,
  totalPointsEarned,
  nextMilestone,
  tier,
}: LoyaltyPointsDashboardProps) {
  const progressPercent = (currentPoints / nextMilestone) * 100

  const tierBenefits = {
    Bronze: ["5% descuento en compras", "Envío gratis >30€"],
    Silver: ["10% descuento en compras", "Envío gratis siempre", "Acceso prioritario a nuevos productos"],
    Gold: ["15% descuento en compras", "Envío gratis + Express", "Acceso VIP a eventos", "Regalo exclusivo anual"],
  }

  return (
    <AnimatedSection>
      <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-2xl border-2 border-primary/20 p-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-serif text-2xl text-foreground mb-2">Puntos de Lealtad</h3>
            <p className="text-muted-foreground">Nivel {tier}</p>
          </div>
          <Zap className="w-12 h-12 text-primary opacity-70" />
        </div>

        {/* Points Display */}
        <div className="bg-card rounded-xl p-6 mb-6">
          <div className="flex items-baseline justify-between mb-4">
            <span className="text-muted-foreground">Puntos disponibles</span>
            <span className="text-5xl font-bold text-primary">{currentPoints}</span>
          </div>
          <p className="text-sm text-muted-foreground">{totalPointsEarned} acumulados totales</p>
        </div>

        {/* Progress to Next Tier */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-semibold text-foreground">Próximo hito: {nextMilestone} puntos</span>
            <span className="text-sm text-muted-foreground">{progressPercent.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-3 overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {nextMilestone - currentPoints} puntos para el siguiente nivel
          </p>
        </div>

        {/* Current Tier Benefits */}
        <div className="bg-card rounded-xl p-4 mb-6">
          <p className="text-sm font-semibold text-foreground mb-3">Beneficios Nivel {tier}</p>
          <ul className="space-y-2">
            {tierBenefits[tier].map((benefit, index) => (
              <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="w-2 h-2 rounded-full bg-primary" />
                {benefit}
              </li>
            ))}
          </ul>
        </div>

        <Button className="w-full rounded-full gap-2 font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105 group" data-testid="button-redeem-points">
          <Gift className="w-4 h-4 group-hover:scale-110 transition-transform" />
          Canjear Puntos
        </Button>
      </div>
    </AnimatedSection>
  )
}
