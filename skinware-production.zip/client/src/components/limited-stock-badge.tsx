import { AnimatedSection } from "@/components/animated-section"
import { cn } from "@/lib/utils"

interface LimitedStockBadgeProps {
  available: number
  total: number
  showPercentage?: boolean
}

export function LimitedStockBadge({ available, total, showPercentage = true }: LimitedStockBadgeProps) {
  const percentage = (available / total) * 100
  const isLow = percentage < 20
  const isCritical = percentage < 10

  return (
    <AnimatedSection className="w-full">
      <div className="bg-muted rounded-lg p-4" data-testid="limited-stock">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold text-foreground">Disponibilidad</span>
          <span className={cn("text-sm font-bold", isCritical ? "text-red-500 animate-pulse" : isLow ? "text-orange-500" : "text-green-500")}>
            {available} de {total}
          </span>
        </div>

        <div className="w-full bg-muted rounded-full h-2.5 overflow-hidden shadow-inner">
          <div
            className={cn(
              "h-full transition-all duration-500 rounded-full shadow-lg",
              isCritical ? "bg-red-500 animate-pulse" : isLow ? "bg-orange-500" : "bg-primary"
            )}
            style={{ width: `${percentage}%` }}
          />
        </div>

        {isCritical && (
          <p className="text-xs text-red-500 font-semibold mt-2 animate-pulse">
            ¡Casi se agotan! Solo quedan {available} unidades
          </p>
        )}

        {isLow && !isCritical && (
          <p className="text-xs text-orange-500 font-semibold mt-2">
            Stock limitado: {available} unidades disponibles
          </p>
        )}

        {showPercentage && (
          <p className="text-xs text-muted-foreground mt-2">
            {percentage.toFixed(0)}% disponible
          </p>
        )}
      </div>
    </AnimatedSection>
  )
}
