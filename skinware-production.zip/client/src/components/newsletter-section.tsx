

import type React from "react"
import { useState } from "react"
import { MailIcon, ArrowRightIcon, CheckIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { AnimatedSection } from "@/components/animated-section"

export function NewsletterSection() {
  const [email, setEmail] = useState("")
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email.trim()) return
    
    if (!validateEmail(email)) {
      setStatus("error")
      setTimeout(() => setStatus("idle"), 3000)
      return
    }

    setStatus("loading")
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setStatus("success")
    setEmail("")
    setTimeout(() => setStatus("idle"), 3000)
  }

  return (
    <section className="py-20 bg-primary/5">
      <div className="container mx-auto px-6">
        <AnimatedSection direction="up" className="max-w-2xl mx-auto text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
            <MailIcon className="w-8 h-8 text-primary" />
          </div>

          <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4 text-balance">
            Únete a la comunidad Skinware
          </h2>

          <div className="inline-block bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-semibold mb-4">
            Descuento 15% + Guía de rutina gratis
          </div>

          <p className="text-muted-foreground mb-8">
            Recibe consejos de skincare, ofertas exclusivas y novedades sobre nuestros productos personalizados
            directamente en tu correo. Suscriptores obtienen 15% en su primer pedido.
          </p>

          {status === "success" ? (
            <div className="flex items-center justify-center gap-2 text-primary">
              <CheckIcon className="w-5 h-5" />
              <span className="font-medium">¡Gracias por suscribirte!</span>
            </div>
          ) : status === "error" ? (
            <div className="text-center">
              <p className="text-sm text-destructive mb-4">Por favor ingresa un email válido</p>
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
                <Input
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="flex-1 rounded-full px-6 h-12 border-border bg-background"
                />
                <Button type="submit" disabled={false} className="rounded-full h-12 px-6 group">
                  <>Suscribirse<ArrowRightIcon className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" /></>
                </Button>
              </form>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="tu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 rounded-full px-6 h-12 border-border bg-background"
              />
              <Button type="submit" disabled={status === "loading"} className="rounded-full h-12 px-6 group">
                {status === "loading" ? (
                  "Enviando..."
                ) : (
                  <>
                    Suscribirse
                    <ArrowRightIcon className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </Button>
            </form>
          )}

          <p className="text-xs text-muted-foreground mt-4">Sin spam. Puedes darte de baja en cualquier momento.</p>
        </AnimatedSection>
      </div>
    </section>
  )
}
