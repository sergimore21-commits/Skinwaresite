

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

export interface CartItem {
  id: string
  name: string
  price: number
  image: string
  quantity: number
}

export interface GiftItem {
  id: string
  name: string
  price: number
  image: string
}

export interface DiscountCode {
  code: string
  percentage: number
  description: string
}

interface CartContextType {
  items: CartItem[]
  addItem: (item: CartItem) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  totalItems: number
  totalPrice: number
  isOpen: boolean
  setIsOpen: (open: boolean) => void
  blackFridayDiscount: number
  setBlackFridayDiscount: (percentage: number) => void
  codeDiscount: number
  setCodeDiscount: (percentage: number) => void
  giftItem: GiftItem | null
  setGiftItem: (gift: GiftItem | null) => void
  appliedCode: string | null
  setAppliedCode: (code: string | null) => void
  validateDiscountCode: (code: string) => DiscountCode | null
}

const CartContext = createContext<CartContextType | undefined>(undefined)

// Available discount codes (mock data)
const VALID_DISCOUNT_CODES: Record<string, DiscountCode> = {
  "SKINCARE20": { code: "SKINCARE20", percentage: 20, description: "20% Descuento Skincare" },
  "SUMMER20": { code: "SUMMER20", percentage: 20, description: "20% Descuento Verano" },
  "WELCOME10": { code: "WELCOME10", percentage: 10, description: "10% Bienvenida" },
  "SKINCARE15": { code: "SKINCARE15", percentage: 15, description: "15% en Skincare" },
  "VIP25": { code: "VIP25", percentage: 25, description: "25% VIP Members" },
  "PROMO30": { code: "PROMO30", percentage: 30, description: "30% Promoción Especial" },
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [isHydrated, setIsHydrated] = useState(false)
  const [blackFridayDiscount, setBlackFridayDiscount] = useState(0)
  const [codeDiscount, setCodeDiscount] = useState(0)
  const [giftItem, setGiftItem] = useState<GiftItem | null>(null)
  const [appliedCode, setAppliedCode] = useState<string | null>(null)

  // Load cart from localStorage on mount & apply Black Friday discount
  useEffect(() => {
    const savedCart = localStorage.getItem("skinware-cart")
    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart))
      } catch (e) {
        console.error("Error parsing cart:", e)
      }
    }
    
    // Check if Black Friday is active (3 días desde las 20:00h) or first purchase (15%)
    const checkDiscount = () => {
      const now = new Date()
      const endTime = new Date(now)
      endTime.setHours(20, 0, 0, 0)
      endTime.setDate(endTime.getDate() + 3)
      
      // Check if Black Friday is active
      if (now.getTime() < endTime.getTime()) {
        setBlackFridayDiscount(40)
        setAppliedCode("blackfriday")
      } else {
        // If not Black Friday, apply 15% first purchase discount
        setBlackFridayDiscount(15)
        setAppliedCode("first-purchase")
      }
    }
    
    checkDiscount()
    
    setIsHydrated(true)
  }, [])

  // Save cart to localStorage when items change
  useEffect(() => {
    if (isHydrated) {
      localStorage.setItem("skinware-cart", JSON.stringify(items))
    }
  }, [items, isHydrated])

  const addItem = (newItem: CartItem) => {
    setItems((prev) => {
      const existingItem = prev.find((item) => item.id === newItem.id)
      if (existingItem) {
        return prev.map((item) =>
          item.id === newItem.id ? { ...item, quantity: item.quantity + newItem.quantity } : item,
        )
      }
      return [...prev, newItem]
    })
    setIsOpen(true)
  }

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity < 1) {
      removeItem(id)
      return
    }
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setItems([])
    setBlackFridayDiscount(0)
    setCodeDiscount(0)
    setGiftItem(null)
    setAppliedCode(null)
  }

  const validateDiscountCode = (code: string): DiscountCode | null => {
    const upperCode = code.toUpperCase().trim()
    return VALID_DISCOUNT_CODES[upperCode] || null
  }

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  const subtotalPrice = items.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const totalDiscountPercentage = blackFridayDiscount + codeDiscount
  const discountAmount = (subtotalPrice * totalDiscountPercentage) / 100
  const totalPrice = subtotalPrice - discountAmount

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
        isOpen,
        setIsOpen,
        blackFridayDiscount,
        setBlackFridayDiscount,
        codeDiscount,
        setCodeDiscount,
        giftItem,
        setGiftItem,
        appliedCode,
        setAppliedCode,
        validateDiscountCode,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
