

import { useState } from "react"
import { Link, useParams } from "wouter"
import { ArrowLeft, Star, ShoppingBag, Heart, Check, Minus, Plus } from "@/components/icons"
import { Truck, Shield, RotateCcw } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AnimatedSection } from "@/components/animated-section"
import { ProductReviews } from "@/components/product-reviews"
import { useCart } from "@/components/cart-provider"
import { useWishlist } from "@/components/wishlist-provider"
import { ProductCompare } from "@/components/product-compare"
import { UrgencyBanner } from "@/components/urgency-banner"
import { LimitedStockBadge } from "@/components/limited-stock-badge"
import { LiveViewersBadge } from "@/components/live-viewers-badge"
import { CountdownTimer } from "@/components/countdown-timer"
import { toast } from "sonner"
import gelLimpiadorImg from "@assets/generated_images/skinware_gel_limpiador_purificante_bottle.png"
import lecheLimpiadoraImg from "@assets/generated_images/skinware_leche_limpiadora_nutritiva_bottle.png"
import serumVitaminaCImg from "@assets/generated_images/skinware_sérum_vitamina_c_bottle.png"
import serumHialuronicoImg from "@assets/generated_images/skinware_sérum_ácido_hialurónico_bottle.png"
import serumRetinolImg from "@assets/generated_images/skinware_sérum_retinol_bottle.png"
import serumNiacinamidaImg from "@assets/generated_images/skinware_sérum_niacinamida_bottle.png"
import protectorSolarImg from "@assets/generated_images/skinware_protector_solar_spf50_tube.png"
import exfolianteImg from "@assets/generated_images/skinware_exfoliante_enzimático_jar.png"
import cremaHidratanteImg from "@assets/generated_images/skinware_crema_hidratante_ligera_jar.png"
import cremaNutritivaImg from "@assets/generated_images/skinware_crema_nutritiva_intensa_jar.png"
import contornoOjosImg from "@assets/generated_images/skinware_contorno_de_ojos_jar.png"
import mascarillaImg from "@assets/generated_images/skinware_mascarilla_purificante_jar.png"

const productsData: Record<string, any> = {
  "1": {
    id: "1",
    name: "Skinware Gel Limpiador Purificante",
    description: "Limpieza profunda que elimina impurezas sin resecar. Con niacinamida y zinc.",
    longDescription:
      "Nuestro Gel Limpiador Purificante está formulado para pieles grasas y mixtas que buscan una limpieza eficaz sin comprometer la hidratación natural de la piel. La combinación de niacinamida al 2% y zinc ayuda a regular la producción de sebo mientras calma posibles irritaciones.",
    price: 28,
    category: "limpiadores",
    skinTypes: ["grasa", "mixta"],
    rating: 4.8,
    reviews: 124,
    image: gelLimpiadorImg,
    badge: "Bestseller",
    ingredients: [
      { name: "Niacinamida", concentration: "2%" },
      { name: "Zinc PCA", concentration: "1.5%" },
      { name: "Aloe Vera Extract", concentration: "5%" },
      { name: "Glicerina", concentration: "3%" },
      { name: "Pantenol", concentration: "2.5%" },
    ],
    howToUse:
      "1. Aplica una pequeña cantidad (tamaño guisante) sobre el rostro húmedo. 2. Masajea suavemente con movimientos circulares durante 30-60 segundos. 3. Enjuaga completamente con agua tibia. 4. Usar mañana y noche. 5. En caso de irritación, reduce frecuencia a 1-2 veces por semana.",
    size: "150ml",
    benefits: [
      "Limpieza profunda sin resecar",
      "Regula la producción de sebo",
      "Minimiza la apariencia de poros",
      "Calma irritaciones",
    ],
    certifications: ["Dermatológicamente testado", "100% vegano", "Cruelty-free", "pH regulado 5.5"],
  },
  "2": {
    id: "2",
    name: "Skinware Leche Limpiadora Nutritiva",
    description: "Limpieza suave que nutre e hidrata la piel seca y sensible.",
    longDescription:
      "La Leche Limpiadora Nutritiva ofrece una limpieza delicada perfecta para pieles secas y sensibles. Enriquecida con aceite de jojoba y vitamina E, elimina suavemente las impurezas mientras nutre y reconforta la piel, dejándola suave y flexible.",
    price: 32,
    category: "limpiadores",
    skinTypes: ["seca", "sensible"],
    rating: 4.9,
    reviews: 98,
    image: lecheLimpiadoraImg,
    ingredients: ["Aceite de Jojoba", "Vitamina E", "Camomila", "Manteca de Karité", "Avena"],
    howToUse:
      "Aplica sobre el rostro seco con movimientos circulares. Retira con algodón húmedo o enjuaga con agua tibia. Ideal para mañana y noche.",
    size: "200ml",
    benefits: ["Limpieza suave sin irritar", "Nutre profundamente", "Calma pieles sensibles", "Deja la piel flexible"],
  },
  "3": {
    id: "3",
    name: "Skinware Sérum Vitamina C 15%",
    description: "Antioxidante potente para luminosidad y tono uniforme. Fórmula estabilizada.",
    longDescription:
      "El Sérum Vitamina C 15% combina ácido L-ascórbico con vitamina E y ácido ferúlico para máxima estabilidad y eficacia. Esta potente fórmula antioxidante protege contra el daño de los radicales libres mientras ilumina visiblemente la piel y reduce la apariencia de manchas oscuras.",
    price: 58,
    category: "serums",
    skinTypes: ["normal", "mixta", "grasa"],
    rating: 4.9,
    reviews: 256,
    image: serumVitaminaCImg,
    badge: "Favorito",
    ingredients: ["Vitamina C 15%", "Vitamina E", "Ácido Ferúlico", "Ácido Hialurónico", "Extracto de Raíz de Regaliz"],
    howToUse:
      "Aplica 4-5 gotas sobre el rostro limpio por la mañana. Deja absorber antes de aplicar hidratante y protector solar. Evita el contacto con los ojos.",
    size: "30ml",
    benefits: [
      "Potente acción antioxidante",
      "Luminosidad visible desde la primera semana",
      "Reduce manchas e hiperpigmentación",
      "Estimula la producción de colágeno",
    ],
  },
  "4": {
    id: "4",
    name: "Skinware Sérum Ácido Hialurónico",
    description: "Hidratación profunda multinivel para todo tipo de pieles.",
    longDescription:
      "Nuestro Sérum de Ácido Hialurónico combina tres pesos moleculares diferentes para proporcionar hidratación en múltiples niveles de la piel. El ácido hialurónico de alto peso molecular hidrata la superficie, mientras que los de menor peso penetran profundamente para una hidratación duradera.",
    price: 48,
    category: "serums",
    skinTypes: ["seca", "normal", "sensible"],
    rating: 4.7,
    reviews: 189,
    image: serumHialuronicoImg,
    ingredients: ["Ácido Hialurónico Triple", "Pantenol", "Glicerina", "Aloe Vera", "Vitamina B5"],
    howToUse:
      "Aplica sobre la piel ligeramente húmeda para potenciar la absorción. Usa 3-4 gotas mañana y noche antes de tu hidratante.",
    size: "30ml",
    benefits: [
      "Hidratación en 3 niveles",
      "Efecto plumping inmediato",
      "Reduce líneas de deshidratación",
      "Piel jugosa todo el día",
    ],
  },
  "5": {
    id: "5",
    name: "Skinware Sérum Retinol 0.5%",
    description: "Renovación celular y tratamiento anti-edad avanzado.",
    longDescription:
      "El Sérum Retinol 0.5% es nuestra fórmula de potencia media, perfecta para quienes ya están familiarizados con el retinol. Encapsulado en escualano para una liberación gradual, minimiza la irritación mientras maximiza los resultados anti-edad.",
    price: 62,
    category: "serums",
    skinTypes: ["normal", "mixta"],
    rating: 4.6,
    reviews: 145,
    image: serumRetinolImg,
    badge: "Nuevo",
    ingredients: ["Retinol 0.5%", "Escualano", "Vitamina E", "Niacinamida", "Ceramidas"],
    howToUse:
      "Usar solo por la noche. Comienza 2-3 veces por semana y aumenta gradualmente. Aplica sobre piel seca después de limpiar. Usa siempre SPF al día siguiente.",
    size: "30ml",
    benefits: [
      "Reduce arrugas y líneas finas",
      "Mejora la textura de la piel",
      "Estimula la renovación celular",
      "Unifica el tono",
    ],
  },
  "6": {
    id: "6",
    name: "Skinware Sérum Niacinamida 10%",
    description: "Control de sebo, poros refinados y barrera cutánea reforzada.",
    longDescription:
      "El Sérum Niacinamida 10% es un todoterreno para pieles grasas y con tendencia acneica. La combinación de niacinamida con zinc regula la producción de sebo, minimiza los poros visibles y fortalece la barrera cutánea para una piel más equilibrada.",
    price: 42,
    category: "serums",
    skinTypes: ["grasa", "mixta"],
    rating: 4.8,
    reviews: 203,
    image: serumNiacinamidaImg,
    ingredients: ["Niacinamida 10%", "Zinc 1%", "Centella Asiática", "Ácido Hialurónico", "Pantenol"],
    howToUse:
      "Aplica 3-4 gotas sobre el rostro limpio mañana y/o noche. Puede usarse antes o después de otros sérums acuosos.",
    size: "30ml",
    benefits: [
      "Regula el exceso de grasa",
      "Minimiza poros visibles",
      "Calma rojeces e inflamación",
      "Fortalece la barrera cutánea",
    ],
  },
  "7": {
    id: "7",
    name: "Skinware Crema Hidratante Ligera",
    description: "Hidratación equilibrada con acabado mate para pieles mixtas y grasas.",
    longDescription:
      "La Crema Hidratante Ligera ofrece la hidratación que tu piel necesita sin añadir pesadez ni brillos. Su fórmula gel-crema de rápida absorción equilibra las zonas grasas mientras hidrata las secas, dejando un acabado fresco y mate.",
    price: 38,
    category: "hidratantes",
    skinTypes: ["grasa", "mixta", "normal"],
    rating: 4.7,
    reviews: 167,
    image: cremaHidratanteImg,
    ingredients: ["Ácido Hialurónico", "Niacinamida", "Aloe Vera", "Extracto de Té Verde", "Centella Asiática"],
    howToUse:
      "Aplica una cantidad generosa sobre el rostro y cuello después de tus sérums. Usar mañana y noche. Ideal como base de maquillaje.",
    size: "50ml",
    benefits: ["Hidratación sin brillos", "Acabado mate natural", "Absorción rápida", "Base perfecta para maquillaje"],
  },
  "8": {
    id: "8",
    name: "Skinware Crema Nutritiva Intensa",
    description: "Nutrición profunda para pieles secas y maduras que necesitan extra cuidado.",
    longDescription:
      "La Crema Nutritiva Intensa es nuestra fórmula más rica, diseñada para pieles que necesitan una nutrición profunda. Con manteca de karité, ceramidas y escualano, repara la barrera cutánea dañada y proporciona confort inmediato a las pieles más secas.",
    price: 52,
    category: "hidratantes",
    skinTypes: ["seca", "sensible"],
    rating: 4.9,
    reviews: 134,
    image: cremaNutritivaImg,
    badge: "Premium",
    ingredients: ["Manteca de Karité", "Ceramidas", "Escualano", "Vitamina E", "Aceite de Argán"],
    howToUse:
      "Aplica generosamente sobre rostro y cuello por la noche. También puede usarse de día en pieles muy secas. Masajea hasta completa absorción.",
    size: "50ml",
    benefits: [
      "Nutrición profunda 24h",
      "Repara la barrera cutánea",
      "Elimina la sensación de tirantez",
      "Efecto antiedad nutritivo",
    ],
  },
  "9": {
    id: "9",
    name: "Skinware Protector Solar SPF50",
    description: "Protección de amplio espectro UVA/UVB con acabado invisible.",
    longDescription:
      "El Protector Solar SPF50 ofrece la máxima protección contra los rayos UVA y UVB con una textura ligera que no deja residuo blanco. Enriquecido con antioxidantes, protege del fotoenvejecimiento mientras hidrata y unifica el tono.",
    price: 34,
    category: "proteccion",
    skinTypes: ["normal", "mixta", "grasa", "seca", "sensible"],
    rating: 4.8,
    reviews: 312,
    image: protectorSolarImg,
    badge: "Esencial",
    ingredients: ["Filtros UVA/UVB", "Vitamina E", "Niacinamida", "Ácido Hialurónico", "Extracto de Aloe"],
    howToUse:
      "Aplica generosamente como último paso de tu rutina de mañana. Reaplica cada 2 horas si hay exposición solar prolongada. Usar 365 días al año.",
    size: "50ml",
    benefits: [
      "Protección SPF50 PA++++",
      "Sin residuo blanco",
      "Hidrata mientras protege",
      "Previene el fotoenvejecimiento",
    ],
  },
  "10": {
    id: "10",
    name: "Skinware Contorno de Ojos Péptidos",
    description: "Tratamiento avanzado para ojeras, bolsas y líneas de expresión.",
    longDescription:
      "El Contorno de Ojos con Péptidos es un tratamiento multifunción que aborda las principales preocupaciones del área ocular. Los péptidos de última generación trabajan junto con cafeína y vitamina K para reducir ojeras, desinflamar bolsas y suavizar patas de gallo.",
    price: 48,
    category: "tratamientos",
    skinTypes: ["normal", "mixta", "seca", "sensible"],
    rating: 4.6,
    reviews: 89,
    image: contornoOjosImg,
    ingredients: ["Complejo de Péptidos", "Cafeína 5%", "Vitamina K", "Ácido Hialurónico", "Retinal Encapsulado"],
    howToUse:
      "Aplica una pequeña cantidad con el dedo anular alrededor del contorno de ojos dando suaves toques. Usar mañana y noche.",
    size: "15ml",
    benefits: ["Reduce ojeras oscuras", "Descongestiona bolsas", "Suaviza líneas finas", "Ilumina el contorno"],
  },
  "11": {
    id: "11",
    name: "Skinware Mascarilla Purificante",
    description: "Limpieza profunda de poros con arcilla y carbón activo.",
    longDescription:
      "La Mascarilla Purificante combina arcilla caolín con carbón activo para una limpieza profunda de los poros. Ideal para pieles grasas y mixtas, absorbe el exceso de sebo y las impurezas mientras el tea tree previene la formación de imperfecciones.",
    price: 28,
    category: "tratamientos",
    skinTypes: ["grasa", "mixta"],
    rating: 4.5,
    reviews: 76,
    image: mascarillaImg,
    ingredients: ["Arcilla Caolín", "Carbón Activo", "Aceite de Tea Tree", "Zinc", "Niacinamida"],
    howToUse:
      "Aplica una capa uniforme sobre el rostro limpio y seco. Deja actuar 10-15 minutos. Retira con agua tibia. Usar 1-2 veces por semana.",
    size: "75ml",
    benefits: [
      "Limpia poros en profundidad",
      "Absorbe exceso de grasa",
      "Previene imperfecciones",
      "Deja la piel mate y suave",
    ],
  },
  "12": {
    id: "12",
    name: "Skinware Exfoliante Enzimático",
    description: "Exfoliación suave con enzimas de frutas para luminosidad instantánea.",
    longDescription:
      "El Exfoliante Enzimático utiliza enzimas naturales de papaya y piña para una exfoliación suave pero efectiva. Ideal para pieles sensibles que no toleran los scrubs físicos, elimina células muertas revelando una piel más luminosa sin irritación.",
    price: 36,
    category: "tratamientos",
    skinTypes: ["normal", "sensible", "seca"],
    rating: 4.7,
    reviews: 112,
    image: exfolianteImg,
    badge: "Clean",
    ingredients: ["Papaína", "Bromelina", "AHA 5%", "Extracto de Calabaza", "Vitamina C"],
    howToUse:
      "Aplica sobre el rostro limpio y seco. Deja actuar 5-10 minutos. Retira con agua tibia. Usar 1-2 veces por semana por la noche.",
    size: "50ml",
    benefits: [
      "Exfoliación sin irritar",
      "Luminosidad instantánea",
      "Suaviza la textura",
      "Prepara para otros activos",
    ],
  },
}

interface ProductDetailProps {
  id: string
}

export function ProductDetail({ id }: ProductDetailProps) {
  const [quantity, setQuantity] = useState(1)
  const [showCompare, setShowCompare] = useState(false)
  const { addItem } = useCart()
  const { isInWishlist, addItem: addToWishlist } = useWishlist()

  const product = productsData[id] || productsData["1"]
  const isWishlisted = isInWishlist(product.id)

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: quantity,
    })
    toast.success(`${product.name} añadido al carrito`, {
      description: `Cantidad: ${quantity}`,
    })
  }

  const handleWishlist = () => {
    addToWishlist({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      category: product.category,
    })
    toast.success(isWishlisted ? "Eliminado de la lista de deseos" : "Agregado a la lista de deseos")
  }

  // Datos de urgencia simulados
  const offerEndDate = new Date(Date.now() + 48 * 60 * 60 * 1000) // 48 horas desde ahora
  const stockAvailable = Math.floor(Math.random() * 20) + 3
  const totalStock = 50
  const viewersCount = Math.floor(Math.random() * 8) + 2

  return (
    <div className="container mx-auto px-6 py-12">
      {/* Urgency Banner */}
      <AnimatedSection className="mb-8">
        <UrgencyBanner type="limited-time" endDate={offerEndDate} />
      </AnimatedSection>

      {/* Breadcrumbs */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
        <Link href="/" className="hover:text-foreground transition-colors">
          Inicio
        </Link>
        <span>/</span>
        <Link href="/productos" className="hover:text-foreground transition-colors">
          Productos
        </Link>
        <span>/</span>
        <span className="text-foreground font-medium">{product.name}</span>
      </div>

      {/* Back button */}
      <Link
        href="/productos"
        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Volver a productos
      </Link>

      <div className="grid lg:grid-cols-2 gap-12">
        {/* Image */}
        <AnimatedSection direction="left">
          <div className="aspect-square rounded-3xl overflow-hidden bg-muted relative group cursor-zoom-in">
            <img src={product.image || "/placeholder.svg"} alt={product.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
            <div className="absolute top-4 left-4 flex flex-col gap-2">
              {product.badge && (
                <Badge className="bg-primary text-primary-foreground">{product.badge}</Badge>
              )}
              <LiveViewersBadge productId={product.id} initialCount={viewersCount} />
            </div>
            <button
              onClick={handleWishlist}
              className="absolute top-4 right-4 p-3 rounded-full bg-background/80 backdrop-blur hover:bg-primary hover:text-primary-foreground transition-all duration-300"
              aria-label="Agregar a favoritos"
              data-testid="button-wishlist"
            >
              <Heart className={`w-5 h-5 ${isWishlisted ? "fill-primary text-primary" : "text-foreground"}`} />
            </button>
          </div>
        </AnimatedSection>

        {/* Details */}
        <AnimatedSection direction="right">
          <div className="flex items-center gap-2 mb-4">
            <div className="flex items-center gap-1">
              <Star className="w-5 h-5 fill-primary text-primary" />
              <span className="font-medium">{product.rating}</span>
            </div>
            <span className="text-muted-foreground">({product.reviews} reseñas)</span>
          </div>

          <h1 className="font-serif text-3xl md:text-4xl text-foreground mb-4">{product.name}</h1>

          <p className="text-muted-foreground text-lg mb-6">{product.longDescription}</p>

          <div className="flex items-baseline gap-2 mb-6">
            <span className="font-serif text-3xl text-foreground">{product.price}€</span>
            <span className="text-muted-foreground">/ {product.size}</span>
          </div>

          {/* Skin Types */}
          <div className="mb-6">
            <p className="text-sm font-medium text-foreground mb-2">Ideal para:</p>
            <div className="flex flex-wrap gap-2">
              {product.skinTypes.map((type: string) => (
                <Badge key={type} variant="secondary" className="capitalize">
                  Piel {type}
                </Badge>
              ))}
            </div>
          </div>

          {/* Urgency Info Box */}
          <AnimatedSection className="bg-primary/10 border-2 border-primary rounded-xl p-4 mb-6">
            <p className="text-sm font-semibold text-primary mb-3">Oferta especial válida por:</p>
            <CountdownTimer endDate={offerEndDate} />
          </AnimatedSection>

          {/* Limited Stock Badge */}
          <div className="mb-6">
            <LimitedStockBadge available={stockAvailable} total={totalStock} />
          </div>

          {/* Quantity and Add to Cart */}
          <div className="flex items-center gap-4 mb-6">
            <div className="flex items-center border border-border rounded-full">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-3 hover:bg-muted transition-colors rounded-l-full"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-12 text-center font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="p-3 hover:bg-muted transition-colors rounded-r-full"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <Button size="lg" className="flex-1 rounded-full h-12 gap-2 font-semibold hover:shadow-lg transition-all duration-300 group" onClick={handleAddToCart}>
              <ShoppingBag className="w-5 h-5 group-hover:scale-110 transition-transform" />
              Añadir al carrito
            </Button>

            <Button
              variant="outline"
              size="icon"
              className={`rounded-full h-12 w-12 ${isWishlisted ? "text-primary border-primary" : ""}`}
              onClick={handleWishlist}
              data-testid="button-wishlist-sidebar"
            >
              <Heart className={`w-5 h-5 ${isWishlisted ? "fill-primary" : ""}`} />
            </Button>
          </div>

          {/* Quick Specs */}
          <div className="grid grid-cols-3 gap-3 mb-6 p-4 bg-muted/30 rounded-xl border border-border">
            <div data-testid={`spec-size-${product.id}`}>
              <p className="text-xs text-muted-foreground mb-1">Tamaño</p>
              <p className="font-semibold text-sm text-foreground">{product.size}</p>
            </div>
            <div data-testid={`spec-type-${product.id}`}>
              <p className="text-xs text-muted-foreground mb-1">Para:</p>
              <p className="font-semibold text-sm text-foreground capitalize">{product.skinTypes?.join(", ")}</p>
            </div>
            <div data-testid={`spec-rating-${product.id}`}>
              <p className="text-xs text-muted-foreground mb-1">Rating</p>
              <p className="font-semibold text-sm text-foreground">{product.rating} / 5</p>
            </div>
          </div>

          {/* Shipping and Guarantee Badges */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <div className="flex flex-col items-center text-center p-3 bg-muted/50 rounded-xl">
              <Truck className="w-5 h-5 text-primary mb-2" />
              <span className="text-xs text-muted-foreground">Envío gratis +40€</span>
            </div>
            <div className="flex flex-col items-center text-center p-3 bg-muted/50 rounded-xl">
              <Shield className="w-5 h-5 text-primary mb-2" />
              <span className="text-xs text-muted-foreground">Garantía 30 días</span>
            </div>
            <div className="flex flex-col items-center text-center p-3 bg-muted/50 rounded-xl">
              <RotateCcw className="w-5 h-5 text-primary mb-2" />
              <span className="text-xs text-muted-foreground">Devolución fácil</span>
            </div>
          </div>

          <Button variant="outline" size="sm" onClick={() => setShowCompare(true)} className="w-full rounded-full mb-8">
            Comparar con otros productos
          </Button>

          {/* Benefits */}
          <div className="bg-muted/50 rounded-2xl p-6 mb-8">
            <p className="font-medium text-foreground mb-4">Beneficios principales:</p>
            <ul className="space-y-2">
              {product.benefits?.map((benefit: string, index: number) => (
                <li key={index} className="flex items-center gap-2 text-muted-foreground">
                  <Check className="w-4 h-4 text-primary" />
                  {benefit}
                </li>
              ))}
            </ul>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="ingredients" className="w-full">
            <TabsList className="grid w-full grid-cols-2 rounded-full h-12">
              <TabsTrigger value="ingredients" className="rounded-full">
                Ingredientes
              </TabsTrigger>
              <TabsTrigger value="howtouse" className="rounded-full">
                Modo de uso
              </TabsTrigger>
            </TabsList>
            <TabsContent value="ingredients" className="mt-4 space-y-4">
              <div className="bg-muted/30 rounded-xl p-6 border border-border space-y-4">
                <div>
                  <p className="text-sm font-semibold text-foreground mb-4">Ingredientes Activos (con concentraciones):</p>
                  <div className="space-y-2">
                    {product.ingredients?.map((ingredient: any, index: number) => (
                      <div key={index} className="flex items-center justify-between bg-card p-3 rounded-lg border border-border hover:border-primary/30 transition-all" data-testid={`ingredient-${product.id}-${index}`}>
                        <p className="text-sm font-medium text-foreground">{typeof ingredient === 'string' ? ingredient : ingredient.name}</p>
                        {ingredient.concentration && (
                          <span className="text-xs font-bold bg-primary/10 text-primary px-2 py-1 rounded">{ingredient.concentration}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="text-xs font-semibold text-foreground mb-2 uppercase">Certificaciones:</p>
                  <div className="grid grid-cols-2 gap-2">
                    {product.certifications?.map((cert: string, i: number) => (
                      <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                        {cert}
                      </div>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground pt-2 italic border-t border-border pt-4">Todos los ingredientes están dermatológicamente probados y formulados según el estándar ISO 16128 (cosmética natural). Libres de parabenos, sulfatos y ftalatos.</p>
              </div>
            </TabsContent>
            <TabsContent value="howtouse" className="mt-4 space-y-4">
              <div className="bg-gradient-to-r from-primary/5 to-secondary/5 p-6 rounded-xl border border-border">
                <h4 className="font-semibold text-foreground mb-3">Modo de aplicación:</h4>
                <p className="text-muted-foreground leading-relaxed mb-4">{product.howToUse}</p>
                <div className="space-y-2 text-sm">
                  <p className="font-medium text-foreground">Consejo profesional:</p>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1">
                    <li>Aplica sobre piel limpia y seca para máxima absorción</li>
                    <li>Usa la cantidad de un guisante o 2-3 gotas según el formato</li>
                    <li>Espera 1-2 minutos entre productos</li>
                    <li>Incrementa gradualmente si es tu primer uso</li>
                  </ul>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </AnimatedSection>
      </div>

      {/* Reviews Section */}
      <ProductReviews
        productId={product.id}
        productName={product.name}
        averageRating={product.rating}
        totalReviews={product.reviews}
      />
    </div>
  )
}
