

import type React from "react"

import { useState } from "react"
import { Link } from "wouter"
import { InstagramIcon, LinkedinIcon, TwitterIcon, ArrowRightIcon, CheckIcon } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { SkinwareLogo } from "@/components/skinware-logo"

export function Footer() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)
  const [loading, setLoading] = useState(false)

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !validateEmail(email)) return

    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setSubscribed(true)
    setLoading(false)
    setEmail("")
  }

  return (
    <footer className="bg-gradient-to-b from-muted/30 to-background border-t border-border/50">
      {/* Security Trust Section */}
      <div className="bg-primary/5 border-b border-primary/10">
        <div className="container mx-auto px-6 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="px-4 py-2 bg-primary/20 rounded-full border border-primary/30">
                <p className="text-xs font-bold text-primary">🔒 PAGOS 100% SEGUROS</p>
              </div>
            </div>
            <p className="text-center text-sm text-muted-foreground mb-6">
              Procesados con <span className="font-semibold text-foreground">Stripe</span> • Encriptación SSL 256-bit • Certificación PCI DSS Nivel 1 • Conforme RGPD
            </p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
              <div className="text-xs text-muted-foreground">
                <p className="font-semibold text-foreground">Datos protegidos</p>
                <p>RGPD completo</p>
              </div>
              <div className="text-xs text-muted-foreground">
                <p className="font-semibold text-foreground">Pagos verificados</p>
                <p>SSL 256-bit</p>
              </div>
              <div className="text-xs text-muted-foreground">
                <p className="font-semibold text-foreground">Certificado</p>
                <p>PCI DSS L1</p>
              </div>
              <div className="text-xs text-muted-foreground">
                <p className="font-semibold text-foreground">Productos</p>
                <p>Dermatológicamente testados</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="border-b border-border/30">
        <div className="container mx-auto px-6 py-16">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="font-serif text-4xl text-foreground mb-4">Únete a la revolución del skincare</h3>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              Sé la primera en recibir consejos personalizados, fórmulas exclusivas, avances en IA y un <span className="font-bold text-primary">15% de descuento</span> en tu primer pedido.
            </p>

            {subscribed ? (
              <div className="flex items-center justify-center gap-2 text-primary animate-in fade-in zoom-in duration-500">
                <CheckIcon className="w-5 h-5" />
                <span className="font-medium">¡Gracias por suscribirte!</span>
              </div>
            ) : (
              <>
                <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto items-center justify-center">
                  <input
                    type="email"
                    placeholder="tu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="flex-1 px-6 py-3 rounded-full border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent focus:shadow-lg transition-all duration-300"
                    data-testid="newsletter-email"
                  />
                  <Button type="submit" className="rounded-full px-8 bg-primary hover:bg-primary/90 font-semibold hover:shadow-lg transition-all duration-300 group" disabled={loading} data-testid="newsletter-subscribe">
                    {loading ? "Enviando..." : "Desbloquear 15%"}
                    <ArrowRightIcon className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </form>
                <p className="text-xs text-muted-foreground mt-4">Sin spam. Puedes darte de baja en cualquier momento.</p>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-16">
        {/* Logo y descripción */}
        <div className="mb-12 pb-12 border-b border-border/30">
          <Link href="/" className="inline-flex items-center gap-3">
            <SkinwareLogo className="w-10 h-10" />
            <span className="font-serif text-2xl tracking-wide text-foreground">Skinware</span>
          </Link>
          <p className="mt-6 text-sm text-muted-foreground max-w-2xl leading-relaxed">
            Reescribiendo el código de la belleza. Fusionamos la cosmética de lujo con la ciencia de datos para ofrecerte productos personalizados que tu piel necesita.
          </p>
          <div className="flex gap-3 mt-8">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
              aria-label="Instagram"
            >
              <InstagramIcon className="h-5 w-5" />
            </a>
            <a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
              aria-label="LinkedIn"
            >
              <LinkedinIcon className="h-5 w-5" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-full bg-primary/10 hover:bg-primary hover:text-primary-foreground transition-all duration-300 hover:scale-110"
              aria-label="Twitter"
            >
              <TwitterIcon className="h-5 w-5" />
            </a>
          </div>
        </div>

        {/* Columnas: Navegación, Recursos, Contacto */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 justify-center">
          {/* Navegación */}
          <div className="text-center">
            <h4 className="font-serif text-sm font-bold text-foreground mb-6 uppercase tracking-wider">Navegación</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Inicio
                </Link>
              </li>
              <li>
                <Link href="/productos" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Productos
                </Link>
              </li>
              <li>
                <Link
                  href="/diagnostico"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  Diagnóstico IA
                </Link>
              </li>
              <li>
                <Link href="/test-piel" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Test de Piel
                </Link>
              </li>
              <li>
                <Link href="/fidelizacion" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Programa VIP
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/nosotros" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Quiénes Somos
                </Link>
              </li>
              <li>
                <Link href="/testimonios" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Testimonios
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Preguntas Frecuentes
                </Link>
              </li>
              <li>
                <Link href="/contacto" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Recursos */}
          <div className="text-center">
            <h4 className="font-serif text-sm font-bold text-foreground mb-6 uppercase tracking-wider">Recursos</h4>
            <ul className="space-y-3">
              <li>
                <Link href="/resultados" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Resultados Reales
                </Link>
              </li>
              <li>
                <Link href="/testimonios" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Testimonios
                </Link>
              </li>
              <li>
                <Link href="/ingredientes" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Guía de Ingredientes
                </Link>
              </li>
              <li>
                <Link href="/sostenibilidad" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Sostenibilidad
                </Link>
              </li>
              <li>
                <Link href="/faq-categorias" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  FAQ por Categoría
                </Link>
              </li>
            </ul>
          </div>

          {/* Contacto */}
          <div className="text-center">
            <h4 className="font-serif text-sm font-bold text-foreground mb-6 uppercase tracking-wider">Contacto</h4>
            <ul className="space-y-3">
              <li className="text-sm text-muted-foreground">Av. Martí i Franquès, 12<br />43007 Tarragona, España</li>
              <li>
                <a
                  href="mailto:info@skinware.es"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  info@skinware.es
                </a>
              </li>
              <li>
                <a
                  href="tel:+34977258430"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  +34 977 258 430
                </a>
              </li>
              <li>
                <a
                  href="mailto:legal@skinware.es"
                  className="text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  legal@skinware.es
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Derechos reservados */}
        <div className="mt-16 pt-12 border-t border-border/30">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <p className="text-xs text-muted-foreground font-medium">
              © {new Date().getFullYear()} Skinware. CIF: B12345678 | Todos los derechos reservados.
            </p>
            <div className="flex gap-6 flex-wrap">
              <Link href="/privacidad" className="text-xs text-muted-foreground hover:text-primary transition-colors duration-300 font-medium">
                Privacidad
              </Link>
              <Link href="/terminos" className="text-xs text-muted-foreground hover:text-primary transition-colors duration-300 font-medium">
                Términos
              </Link>
              <Link href="/legal" className="text-xs text-muted-foreground hover:text-primary transition-colors duration-300 font-medium">
                Responsable Legal
              </Link>
              <Link href="/cookies" className="text-xs text-muted-foreground hover:text-primary transition-colors duration-300 font-medium">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
