import { useState, useRef, useEffect } from "react"
import { MessageCircle, X, Send } from "lucide-react"
import { AnimatedSection } from "@/components/animated-section"

interface Message {
  id: string
  text: string
  sender: "user" | "bot"
  timestamp: Date
}

const initialBotMessages = [
  "¡Hola! 👋 Soy el asistente de Skinware.",
  "¿En qué puedo ayudarte hoy?",
  "Puedo ayudarte con: productos, diagnóstico IA, garantía, envíos y más.",
]

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    { id: "1", text: initialBotMessages[0], sender: "bot", timestamp: new Date() },
    { id: "2", text: initialBotMessages[1], sender: "bot", timestamp: new Date(Date.now() + 500) },
  ])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSendMessage = () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate bot response
    setTimeout(() => {
      const botResponses: { [key: string]: string } = {
        "diagnóstico": "¡Perfecto! Nuestro diagnóstico IA analiza 47 parámetros de tu piel. Toma solo 2 minutos. ¿Quieres empezar?",
        "garantía": "Tenemos garantía de 14 días. Si no ves resultados, te devolvemos tu dinero al 100%. Sin preguntas.",
        "envío": "Enviamos a toda España en 24-48 horas. Envío GRATIS en pedidos mayores a 50€.",
        "precio": "Nuestros productos van desde 25€ a 85€. Todos con fórmula personalizada.",
        "hola": "¡Hola! 👋 ¿En qué puedo ayudarte? Cuéntame sobre tu piel o tus dudas.",
        "ayuda": "Puedo ayudarte con:\n• Diagnóstico IA\n• Información de productos\n• Garantía y devoluciones\n• Envíos\n• Ingredientes\n\n¿Qué necesitas?",
        "default": "Buena pregunta. Para más detalles, ponte en contacto con nuestro equipo en support@skinware.es. ¿Hay algo más en lo que pueda ayudarte?",
      }

      const lowerInput = inputValue.toLowerCase()
      let response = botResponses.default

      for (const key of Object.keys(botResponses)) {
        if (lowerInput.includes(key)) {
          response = botResponses[key]
          break
        }
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: "bot",
        timestamp: new Date(),
      }

      setMessages(prev => [...prev, botMessage])
      setIsTyping(false)
    }, 600)
  }

  return (
    <>
      {/* Chat Widget Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-primary text-primary-foreground rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all z-40 flex items-center justify-center group"
        aria-label="Abrir chat"
        data-testid="button-open-chat"
      >
        <MessageCircle className="w-6 h-6 group-hover:hidden" />
        <X className="w-6 h-6 hidden group-hover:block" />
      </button>

      {/* Chat Window */}
      {isOpen && (
        <AnimatedSection direction="up" className="fixed bottom-24 right-6 z-50 w-96 max-w-[calc(100vw-2rem)]">
          <div className="bg-card rounded-2xl shadow-2xl border border-border overflow-hidden flex flex-col h-96 md:h-[500px]">
            {/* Header */}
            <div className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">Skinware Support</h3>
                  <p className="text-xs opacity-90">Respuesta en menos de 2 horas</p>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-primary-foreground/20 p-1 rounded transition-colors"
                  aria-label="Cerrar chat"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-background to-background/50">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                  data-testid={`message-${msg.sender}-${msg.id}`}
                >
                  <div
                    className={`max-w-xs px-4 py-2 rounded-lg text-sm ${
                      msg.sender === "user"
                        ? "bg-primary text-primary-foreground rounded-br-none"
                        : "bg-muted text-foreground rounded-bl-none"
                    }`}
                  >
                    {msg.text.split("\n").map((line, i) => (
                      <div key={i}>{line}</div>
                    ))}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-muted text-foreground px-4 py-2 rounded-lg rounded-bl-none">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce delay-100" />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce delay-200" />
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  onKeyPress={e => e.key === "Enter" && handleSendMessage()}
                  placeholder="Escribe tu pregunta..."
                  className="flex-1 bg-background border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-primary transition-colors"
                  data-testid="input-chat-message"
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!inputValue.trim()}
                  className="bg-primary text-primary-foreground p-2 rounded-lg hover:bg-primary/90 disabled:opacity-50 transition-colors"
                  aria-label="Enviar mensaje"
                  data-testid="button-send-message"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </AnimatedSection>
      )}
    </>
  )
}
