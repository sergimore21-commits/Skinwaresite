

import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { StarIcon, FilterIcon, SearchIcon } from "@/components/icons"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"
import { Link } from "wouter"
import gelLimpiadorImg from "@assets/generated_images/skinware_gel_limpiador_purificante_bottle.png"
import lecheLimpiadoraImg from "@assets/generated_images/skinware_leche_limpiadora_nutritiva_bottle.png"
import serumVitaminaCImg from "@assets/generated_images/skinware_sérum_vitamina_c_bottle.png"
import serumHialuronicoImg from "@assets/generated_images/skinware_sérum_ácido_hialurónico_bottle.png"
import serumRetinolImg from "@assets/generated_images/skinware_sérum_retinol_bottle.png"
import serumNiacinamidaImg from "@assets/generated_images/skinware_sérum_niacinamida_bottle.png"
import protectorSolarImg from "@assets/generated_images/skinware_protector_solar_spf50_tube.png"
import exfolianteImg from "@assets/generated_images/skinware_exfoliante_enzimático_jar.png"
import cremaHidratanteImg from "@assets/generated_images/skinware_crema_hidratante_ligera_jar.png"
import cremaNutritivaImg from "@assets/generated_images/skinware_crema_nutritiva_intensa_jar.png"
import contornoOjosImg from "@assets/generated_images/skinware_contorno_de_ojos_jar.png"
import mascarillaImg from "@assets/generated_images/skinware_mascarilla_purificante_jar.png"

type Category = "all" | "limpiadores" | "serums" | "hidratantes" | "proteccion" | "tratamientos"
type SkinType = "all" | "grasa" | "seca" | "mixta" | "sensible" | "normal"
type Concern = "all" | "antienvejecimiento" | "acne" | "manchas" | "hidratacion" | "luminosidad"

interface Product {
  id: string
  name: string
  description: string
  price: number
  category: Exclude<Category, "all">
  skinTypes: Exclude<SkinType, "all">[]
  concerns: Exclude<Concern, "all">[]
  rating: number
  reviews: number
  image: string
  badge?: string
  ingredients: string[]
}

const products: Product[] = [
  {
    id: "1",
    name: "Skinware Gel Limpiador Purificante",
    description: "Limpieza profunda que elimina impurezas sin resecar.",
    price: 28,
    category: "limpiadores",
    skinTypes: ["grasa", "mixta"],
    concerns: ["acne", "luminosidad"],
    rating: 4.8,
    reviews: 124,
    image: gelLimpiadorImg,
    badge: "Bestseller",
    ingredients: ["Niacinamida", "Zinc", "Aloe Vera"],
  },
  {
    id: "2",
    name: "Skinware Leche Limpiadora Nutritiva",
    description: "Limpieza suave que nutre e hidrata.",
    price: 32,
    category: "limpiadores",
    skinTypes: ["seca", "sensible"],
    concerns: ["hidratacion"],
    rating: 4.9,
    reviews: 98,
    image: lecheLimpiadoraImg,
    ingredients: ["Aceite de Jojoba", "Vitamina E", "Camomila"],
  },
  {
    id: "3",
    name: "Skinware Sérum Vitamina C 15%",
    description: "Antioxidante potente para luminosidad.",
    price: 58,
    category: "serums",
    skinTypes: ["normal", "mixta", "grasa"],
    concerns: ["manchas", "luminosidad", "antienvejecimiento"],
    rating: 4.9,
    reviews: 256,
    image: serumVitaminaCImg,
    badge: "Favorito",
    ingredients: ["Vitamina C", "Vitamina E", "Ácido Ferúlico"],
  },
  {
    id: "4",
    name: "Skinware Sérum Ácido Hialurónico",
    description: "Hidratación profunda multinivel.",
    price: 48,
    category: "serums",
    skinTypes: ["seca", "normal", "sensible"],
    concerns: ["hidratacion", "antienvejecimiento"],
    rating: 4.7,
    reviews: 189,
    image: serumHialuronicoImg,
    ingredients: ["Ácido Hialurónico", "Pantenol", "Glicerina"],
  },
  {
    id: "5",
    name: "Skinware Sérum Retinol 0.5%",
    description: "Renovación celular y anti-edad.",
    price: 62,
    category: "serums",
    skinTypes: ["normal", "mixta"],
    concerns: ["antienvejecimiento", "manchas"],
    rating: 4.6,
    reviews: 145,
    image: serumRetinolImg,
    badge: "Nuevo",
    ingredients: ["Retinol", "Escualano", "Vitamina E"],
  },
  {
    id: "6",
    name: "Skinware Sérum Niacinamida 10%",
    description: "Control de sebo y poros refinados.",
    price: 42,
    category: "serums",
    skinTypes: ["grasa", "mixta"],
    concerns: ["acne", "luminosidad"],
    rating: 4.8,
    reviews: 203,
    image: serumNiacinamidaImg,
    ingredients: ["Niacinamida", "Zinc", "Centella Asiática"],
  },
  {
    id: "7",
    name: "Skinware Crema Hidratante Ligera",
    description: "Hidratación equilibrada sin sensación grasa.",
    price: 38,
    category: "hidratantes",
    skinTypes: ["grasa", "mixta", "normal"],
    concerns: ["hidratacion"],
    rating: 4.7,
    reviews: 167,
    image: cremaHidratanteImg,
    ingredients: ["Ácido Hialurónico", "Niacinamida", "Aloe Vera"],
  },
  {
    id: "8",
    name: "Skinware Crema Nutritiva Intensa",
    description: "Nutrición profunda para pieles secas.",
    price: 52,
    category: "hidratantes",
    skinTypes: ["seca", "sensible"],
    concerns: ["hidratacion", "antienvejecimiento"],
    rating: 4.9,
    reviews: 134,
    image: cremaNutritivaImg,
    badge: "Premium",
    ingredients: ["Manteca de Karité", "Ceramidas", "Escualano"],
  },
  {
    id: "9",
    name: "Skinware Protector Solar SPF50",
    description: "Protección de amplio espectro.",
    price: 34,
    category: "proteccion",
    skinTypes: ["normal", "mixta", "grasa", "seca", "sensible"],
    concerns: ["antienvejecimiento", "manchas"],
    rating: 4.8,
    reviews: 312,
    image: protectorSolarImg,
    badge: "Esencial",
    ingredients: ["Filtros UVA/UVB", "Vitamina E", "Niacinamida"],
  },
  {
    id: "10",
    name: "Skinware Contorno de Ojos Péptidos",
    description: "Reduce ojeras, bolsas y líneas finas.",
    price: 48,
    category: "tratamientos",
    skinTypes: ["normal", "mixta", "seca", "sensible"],
    concerns: ["antienvejecimiento"],
    rating: 4.6,
    reviews: 89,
    image: contornoOjosImg,
    ingredients: ["Péptidos", "Cafeína", "Vitamina K"],
  },
  {
    id: "11",
    name: "Skinware Mascarilla Purificante",
    description: "Limpieza profunda de poros.",
    price: 28,
    category: "tratamientos",
    skinTypes: ["grasa", "mixta"],
    concerns: ["acne"],
    rating: 4.5,
    reviews: 76,
    image: mascarillaImg,
    ingredients: ["Arcilla", "Carbón Activo", "Tea Tree"],
  },
  {
    id: "12",
    name: "Skinware Exfoliante Enzimático",
    description: "Exfoliación suave con enzimas.",
    price: 36,
    category: "tratamientos",
    skinTypes: ["normal", "sensible", "seca"],
    concerns: ["luminosidad", "manchas"],
    rating: 4.7,
    reviews: 112,
    image: exfolianteImg,
    badge: "Clean",
    ingredients: ["Papaína", "Bromelina", "AHA"],
  },
]

const categories = [
  { value: "all", label: "Todos" },
  { value: "limpiadores", label: "Limpiadores" },
  { value: "serums", label: "Sérums" },
  { value: "hidratantes", label: "Hidratantes" },
  { value: "proteccion", label: "Protección" },
  { value: "tratamientos", label: "Tratamientos" },
]

const skinTypes = [
  { value: "all", label: "Todos los tipos" },
  { value: "grasa", label: "Grasa" },
  { value: "seca", label: "Seca" },
  { value: "mixta", label: "Mixta" },
  { value: "sensible", label: "Sensible" },
  { value: "normal", label: "Normal" },
]

const concerns = [
  { value: "all", label: "Todas" },
  { value: "antienvejecimiento", label: "Anti-edad" },
  { value: "acne", label: "Acné" },
  { value: "manchas", label: "Manchas" },
  { value: "hidratacion", label: "Hidratación" },
  { value: "luminosidad", label: "Luminosidad" },
]

export function ProductCatalog() {
  const [selectedCategory, setSelectedCategory] = useState<Category>("all")
  const [selectedSkinType, setSelectedSkinType] = useState<SkinType>("all")
  const [selectedConcern, setSelectedConcern] = useState<Concern>("all")
  const [search, setSearch] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [wishlist, setWishlist] = useState<Set<string>>(new Set())

  // Load wishlist from localStorage
  useState(() => {
    const saved = localStorage.getItem("skinware-wishlist")
    if (saved) {
      const items = JSON.parse(saved)
      setWishlist(new Set(items.map((p: any) => p.id)))
    }
  })[1]

  const toggleWishlist = (product: Product) => {
    const updated = new Set(wishlist)
    if (updated.has(product.id)) {
      updated.delete(product.id)
    } else {
      updated.add(product.id)
    }
    setWishlist(updated)
    
    // Save to localStorage
    const savedWishlist = localStorage.getItem("skinware-wishlist") ? JSON.parse(localStorage.getItem("skinware-wishlist")!) : []
    if (updated.has(product.id)) {
      if (!savedWishlist.find((p: any) => p.id === product.id)) {
        savedWishlist.push(product)
      }
    } else {
      const idx = savedWishlist.findIndex((p: any) => p.id === product.id)
      if (idx > -1) savedWishlist.splice(idx, 1)
    }
    localStorage.setItem("skinware-wishlist", JSON.stringify(savedWishlist))
  }

  const filteredProducts = products.filter((product) => {
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    const matchesSkinType = selectedSkinType === "all" || product.skinTypes.includes(selectedSkinType)
    const matchesConcern = selectedConcern === "all" || product.concerns.includes(selectedConcern)
    const matchesSearch =
      product.name.toLowerCase().includes(search.toLowerCase()) ||
      product.description.toLowerCase().includes(search.toLowerCase())
    return matchesCategory && matchesSkinType && matchesConcern && matchesSearch
  })

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="bg-gradient-to-b from-primary/5 to-background py-16">
        <div className="container mx-auto px-6">
          <AnimatedSection direction="up" className="text-center max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-4">Nuestros Productos</h1>
            <p className="text-muted-foreground text-lg">
              Descubre nuestra colección de productos formulados con ingredientes de alta eficacia para cada tipo de
              piel.
            </p>
          </AnimatedSection>
        </div>
      </section>

      <div className="container mx-auto px-6 py-12">
        {/* Search and Filter Toggle */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 justify-center items-center">
          <div className="relative w-full md:w-auto max-w-md">
            <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar productos..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-12 h-12 rounded-full border-border"
            />
          </div>
          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="rounded-full gap-2 bg-transparent"
          >
            <FilterIcon className="w-4 h-4" />
            Filtros
          </Button>
        </div>

        {/* Filters */}
        {showFilters && (
          <AnimatedSection direction="up" className="bg-card rounded-2xl p-6 border border-border mb-8">
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h3 className="font-medium text-foreground mb-3">Categoría</h3>
                <div className="flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <button
                      key={cat.value}
                      onClick={() => setSelectedCategory(cat.value as Category)}
                      className={cn(
                        "px-3 py-1.5 rounded-full text-sm transition-all",
                        selectedCategory === cat.value
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-muted/80",
                      )}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-3">Tipo de piel</h3>
                <div className="flex flex-wrap gap-2">
                  {skinTypes.map((type) => (
                    <button
                      key={type.value}
                      onClick={() => setSelectedSkinType(type.value as SkinType)}
                      className={cn(
                        "px-3 py-1.5 rounded-full text-sm transition-all",
                        selectedSkinType === type.value
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-muted/80",
                      )}
                    >
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="font-medium text-foreground mb-3">Preocupación</h3>
                <div className="flex flex-wrap gap-2">
                  {concerns.map((concern) => (
                    <button
                      key={concern.value}
                      onClick={() => setSelectedConcern(concern.value as Concern)}
                      className={cn(
                        "px-3 py-1.5 rounded-full text-sm transition-all",
                        selectedConcern === concern.value
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-muted/80",
                      )}
                    >
                      {concern.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </AnimatedSection>
        )}

        {/* Category Pills (Quick Access) */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value as Category)}
              className={cn(
                "px-4 py-2 rounded-full text-sm transition-all",
                selectedCategory === cat.value
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80",
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map((product, index) => (
              <AnimatedSection key={product.id} direction="up" delay={index * 50}>
                <Link href={`/productos/${product.id}`} className="group block h-full">
                  <article className="bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 h-full flex flex-col">
                    <div className="aspect-square overflow-hidden relative">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        loading="lazy"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      {product.badge && (
                        <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground">
                          {product.badge}
                        </Badge>
                      )}
                    </div>
                    <div className="p-5 flex flex-col flex-1">
                      <div className="flex items-center gap-1 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <StarIcon
                            key={i}
                            className={cn(
                              "w-3 h-3",
                              i < Math.floor(product.rating) ? "fill-primary text-primary" : "text-muted",
                            )}
                          />
                        ))}
                        <span className="text-xs text-muted-foreground ml-1">({product.reviews})</span>
                      </div>
                      <h3 className="font-medium text-foreground group-hover:text-primary transition-colors mb-1">
                        {product.name}
                      </h3>
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-3 flex-1">{product.description}</p>
                      <div className="flex flex-col gap-3 pt-2">
                        <span className="font-semibold text-foreground text-lg">{product.price}€</span>
                        <div className="flex gap-2 w-full">
                          <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); toggleWishlist(product); }} className="p-2 rounded-full hover:bg-muted transition-colors flex-shrink-0" aria-label="Agregar a favoritos" data-testid={`wishlist-toggle-${product.id}`}>
                            <svg className={cn("w-4 h-4 transition-colors", wishlist.has(product.id) ? "fill-primary text-primary" : "text-foreground hover:text-primary")} fill={wishlist.has(product.id) ? "currentColor" : "none"} stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                            </svg>
                          </button>
                          <Button size="sm" className="flex-1 rounded-full text-xs bg-primary text-primary-foreground hover:bg-primary/90 hover:shadow-lg transition-all">
                            Comprar
                          </Button>
                        </div>
                      </div>
                    </div>
                  </article>
                </Link>
              </AnimatedSection>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No se encontraron productos con los filtros seleccionados.</p>
            <Button
              variant="outline"
              onClick={() => {
                setSelectedCategory("all")
                setSelectedSkinType("all")
                setSelectedConcern("all")
                setSearch("")
              }}
              className="mt-4 rounded-full"
            >
              Limpiar filtros
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
