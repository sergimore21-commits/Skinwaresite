import { useState, useEffect } from "react"
import { ShoppingCart } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { Button } from "@/components/ui/button"

export function CartCTAFloating() {
  const { items, totalPrice, setIsOpen, discountAmount } = useCart()
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Mostrar el CTA cuando hay items en el carrito y usuario scrollea
    const handleScroll = () => {
      if (items.length > 0 && window.scrollY > 500) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [items.length])

  if (!isVisible || items.length === 0) return null

  return (
    <div className="fixed top-6 right-6 z-30 animate-in slide-in-from-top-4 fade-in duration-300">
      <Button
        onClick={() => setIsOpen(true)}
        size="lg"
        className="bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary shadow-2xl hover:shadow-3xl transition-all duration-300 hover:scale-105 rounded-full font-black flex items-center gap-3"
      >
        <ShoppingCart className="w-5 h-5" />
        <div className="text-left">
          <span className="block text-sm">
            {items.length} {items.length === 1 ? "item" : "items"}
          </span>
          <span className="block text-xs font-semibold">
            {discountAmount > 0 && `¡Ahorras ${discountAmount.toFixed(0)}€! `}
            {(totalPrice + (items.length > 0 ? 4.95 : 0)).toFixed(2)}€
          </span>
        </div>
      </Button>
    </div>
  )
}
