import { useState } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface PreferencesCardProps {
  skinType: string
  concerns: string[]
  newsletter: boolean
  notifications: boolean
}

export function PreferencesCard({ skinType, concerns, newsletter, notifications }: PreferencesCardProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [prefs, setPrefs] = useState({
    newsletter,
    notifications,
  })

  return (
    <AnimatedSection>
      <div className="bg-card rounded-2xl border border-border p-8">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-serif text-2xl text-foreground">Preferencias</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditing(!isEditing)}
            data-testid="button-edit-preferences"
          >
            {isEditing ? "Guardar" : "Editar"}
          </Button>
        </div>

        {/* Skin Profile */}
        <div className="mb-6 pb-6 border-b border-border">
          <p className="text-sm text-muted-foreground mb-2">Tipo de Piel</p>
          <Badge className="bg-primary/20 text-primary">{skinType}</Badge>
          <div className="mt-4">
            <p className="text-sm text-muted-foreground mb-2">Preocupaciones</p>
            <div className="flex flex-wrap gap-2">
              {concerns.map((concern) => (
                <Badge key={concern} variant="secondary">
                  {concern}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        {/* Communication Preferences */}
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div>
              <p className="font-semibold text-foreground text-sm">Newsletter</p>
              <p className="text-xs text-muted-foreground">Ofertas y novedades</p>
            </div>
            <input
              type="checkbox"
              checked={prefs.newsletter}
              onChange={(e) => setPrefs({ ...prefs, newsletter: e.target.checked })}
              disabled={!isEditing}
              className="w-5 h-5 cursor-pointer"
              data-testid="toggle-newsletter"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
            <div>
              <p className="font-semibold text-foreground text-sm">Notificaciones</p>
              <p className="text-xs text-muted-foreground">Actualizaciones de órdenes</p>
            </div>
            <input
              type="checkbox"
              checked={prefs.notifications}
              onChange={(e) => setPrefs({ ...prefs, notifications: e.target.checked })}
              disabled={!isEditing}
              className="w-5 h-5 cursor-pointer"
              data-testid="toggle-notifications"
            />
          </div>
        </div>
      </div>
    </AnimatedSection>
  )
}
