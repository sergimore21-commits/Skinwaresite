import { useState, useEffect } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Flame } from "lucide-react"
import { CountdownTimer } from "@/components/countdown-timer"

interface FlashSaleBannerProps {
  discount: number
  endDate: Date
  productCount?: number
}

export function FlashSaleBanner({ discount, endDate, productCount }: FlashSaleBannerProps) {
  const [isActive, setIsActive] = useState(true)

  const handleExpired = () => {
    setIsActive(false)
  }

  if (!isActive) return null

  return (
    <AnimatedSection className="w-full relative">
      <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-6 text-primary-foreground border-2 border-primary/30 backdrop-blur-sm shadow-lg">
        <div className="grid md:grid-cols-3 gap-6 items-center">
          {/* Left: Title and Discount */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-2">
              <Flame className="w-6 h-6 animate-bounce" />
              <Badge variant="secondary" className="bg-primary-foreground/20">
                FLASH SALE
              </Badge>
            </div>
            <h2 className="text-3xl font-bold mb-1">{discount}% OFF</h2>
            <p className="text-sm text-primary-foreground/80">En todos los productos seleccionados</p>
          </div>

          {/* Center: Timer */}
          <div className="md:col-span-1 flex justify-center">
            <CountdownTimer endDate={endDate} onExpired={handleExpired} className="text-primary-foreground" />
          </div>

          {/* Right: CTA */}
          <div className="md:col-span-1 flex flex-col gap-2">
            {productCount && (
              <p className="text-sm text-primary-foreground/80">
                Solo {productCount} productos con esta oferta
              </p>
            )}
            <Button
              size="lg"
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 rounded-full font-bold"
              data-testid="button-flash-sale"
            >
              Ver Oferta
            </Button>
          </div>
        </div>
      </div>
    </AnimatedSection>
  )
}
