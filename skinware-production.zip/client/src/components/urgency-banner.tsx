import { useState, useEffect } from "react"
import { AnimatedSection } from "@/components/animated-section"
import { Badge } from "@/components/ui/badge"

interface UrgencyBannerProps {
  type: "limited-stock" | "limited-time" | "trending" | "last-chance"
  message?: string
  endDate?: Date
  stockCount?: number
}

export function UrgencyBanner({ type, message, endDate, stockCount }: UrgencyBannerProps) {
  const [timeLeft, setTimeLeft] = useState<string>("")
  const [isEnding, setIsEnding] = useState(false)

  useEffect(() => {
    if (!endDate) return

    const updateTimer = () => {
      const now = new Date()
      const diff = endDate.getTime() - now.getTime()

      if (diff <= 0) {
        setTimeLeft("Oferta finalizada")
        return
      }

      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)

      setTimeLeft(`${hours}h ${minutes}m ${seconds}s`)
      setIsEnding(hours < 2)
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)
    return () => clearInterval(interval)
  }, [endDate])

  const getBgColor = () => {
    if (type === "last-chance" || isEnding) return "bg-primary/90"
    if (type === "limited-time") return "bg-primary/85"
    if (type === "limited-stock") return "bg-primary/80"
    return "bg-primary/75"
  }

  const getMessage = () => {
    switch (type) {
      case "limited-stock":
        return message || `Solo ${stockCount} unidades disponibles`
      case "limited-time":
        return message || `Oferta especial: ${timeLeft}`
      case "last-chance":
        return message || `Última oportunidad: ${timeLeft}`
      case "trending":
        return message || "Tendencia: Muchas personas viendo esto"
      default:
        return message || "Oferta limitada"
    }
  }

  return (
    <AnimatedSection>
      <div className={`${getBgColor()} text-primary-foreground py-3 px-6 rounded-lg flex items-center justify-between backdrop-blur-sm border border-primary/30`} data-testid={`urgency-${type}`}>
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className="animate-bounce">
            {type === "limited-stock" && "📦"}
            {type === "limited-time" && "⏱️"}
            {type === "last-chance" && "🔥"}
            {type === "trending" && "📈"}
          </Badge>
          <span className="font-semibold text-sm md:text-base">{getMessage()}</span>
        </div>
      </div>
    </AnimatedSection>
  )
}
