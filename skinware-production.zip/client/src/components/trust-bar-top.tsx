import { Shield, Truck, Star } from "lucide-react"

export function TrustBarTop() {
  return (
    <div className="bg-gradient-to-r from-primary/90 to-primary/80 text-primary-foreground py-3 border-b border-primary/30 sticky top-[73px] z-30">
      <div className="container mx-auto px-6">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12 text-sm font-semibold">
          <div className="flex items-center gap-2">
            <Star className="w-4 h-4 fill-primary-foreground" />
            <span>4.8/5 (2,400+ opiniones)</span>
          </div>
          <div className="hidden sm:block w-px h-5 bg-primary-foreground/30" />
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Garantía 14 días</span>
          </div>
          <div className="hidden sm:block w-px h-5 bg-primary-foreground/30" />
          <div className="flex items-center gap-2">
            <Truck className="w-4 h-4" />
            <span>Envío gratis +50€</span>
          </div>
        </div>
      </div>
    </div>
  )
}
