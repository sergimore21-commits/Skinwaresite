import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { BlogList } from "@/components/blog-list"

export default function BlogPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <BlogList />
      </main>
      <Footer />
    </>
  )
}
