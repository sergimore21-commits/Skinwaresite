import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ProductDetail } from "@/components/product-detail"
import { useRoute } from "wouter"

export default function ProductPage() {
  const [match, params] = useRoute("/productos/:id");
  
  if (!match) return null;

  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <ProductDetail id={params.id} />
      </main>
      <Footer />
    </>
  )
}
