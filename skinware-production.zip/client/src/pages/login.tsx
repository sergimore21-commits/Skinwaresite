import { useState } from "react"
import { Link, useLocation } from "wouter"
import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { EyeIcon, EyeOffIcon } from "lucide-react"

const AppleLogo = () => (
  <img src="/apple-logo.png" alt="Apple" className="w-5 h-5 mr-2 inline" />
)

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [, navigate] = useLocation()

  const isFormValid = email && password && password.length >= 6

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!isFormValid) return

    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setSubmitted(true)
    setIsSubmitting(false)

    setTimeout(() => {
      navigate("/dashboard")
    }, 2000)
  }

  if (submitted) {
    return (
      <>
        <Navbar />
        <main className="min-h-screen bg-gradient-to-b from-background via-muted/20 to-background pt-24 pb-16 px-6">
          <div className="container mx-auto max-w-md">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 mb-6 animate-in fade-in zoom-in duration-500">
                <span className="text-3xl">✓</span>
              </div>
              <h1 className="font-serif text-4xl font-bold text-foreground mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
                ¡Bienvenida de vuelta!
              </h1>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
                Sesión iniciada correctamente. Redireccionando a tu panel...
              </p>
              <div className="animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
                <p className="text-sm text-muted-foreground">Redireccionando en unos momentos...</p>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gradient-to-b from-background via-muted/20 to-background pt-24 pb-16">
        <div className="container mx-auto max-w-md px-6">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="font-serif text-4xl font-bold text-foreground mb-3">Inicia Sesión</h1>
            <p className="text-muted-foreground text-lg">
              Accede a tu cuenta y continúa con tu rutina personalizada
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@email.com"
                className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300"
                required
                data-testid="input-email"
              />
            </div>

            {/* Password */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-semibold text-foreground">Contraseña</label>
                <Link href="/forgot-password" className="text-xs text-primary hover:text-primary/80 underline">
                  ¿Olvidaste tu contraseña?
                </Link>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Tu contraseña"
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300 pr-10"
                  required
                  data-testid="input-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                >
                  {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="remember"
                className="w-5 h-5 rounded border-border bg-background text-primary cursor-pointer"
                data-testid="checkbox-remember"
              />
              <label htmlFor="remember" className="text-sm text-muted-foreground cursor-pointer">
                Recuerda mis datos
              </label>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={!isFormValid || isSubmitting}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg py-3 font-semibold hover:shadow-lg transition-all duration-300 mt-8"
              data-testid="button-login"
            >
              {isSubmitting ? "Iniciando sesión..." : "Iniciar Sesión"}
            </Button>
          </form>

          {/* Signup Link */}
          <p className="text-center text-sm text-muted-foreground mt-8">
            ¿No tienes cuenta?{" "}
            <Link href="/register" className="text-primary hover:text-primary/80 font-semibold underline">
              Regístrate aquí
            </Link>
          </p>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border/30"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-background text-muted-foreground">O continúa con</span>
            </div>
          </div>

          {/* Social Login */}
          <div className="grid grid-cols-2 gap-2 mb-8">
            <Button
              variant="outline"
              className="rounded-lg py-3 font-semibold border border-border hover:bg-muted transition-all duration-300 text-sm"
              type="button"
              title="Iniciar sesión con Google"
            >
              <span className="mr-1">G</span> Google
            </Button>
            <Button
              variant="outline"
              className="rounded-lg py-3 font-semibold border border-border hover:bg-muted transition-all duration-300 text-sm"
              type="button"
              title="Iniciar sesión con Apple"
            >
              <AppleLogo /> Apple
            </Button>
          </div>

          {/* Trust Badges */}
          <div className="mt-12 pt-8 border-t border-border/30">
            <p className="text-center text-xs text-muted-foreground mb-4">Tu seguridad es nuestra prioridad</p>
            <div className="flex justify-center items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>🔒</span>
                <span>SSL Encriptado</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>✓</span>
                <span>RGPD Compliant</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>✓</span>
                <span>PCI DSS L1</span>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
