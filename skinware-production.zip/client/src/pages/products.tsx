import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ProductCatalog } from "@/components/product-catalog"

export default function ProductsPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <ProductCatalog />
      </main>
      <Footer />
    </>
  )
}
