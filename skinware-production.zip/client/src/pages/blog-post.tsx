import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { BlogArticle } from "@/components/blog-article"
import { useRoute } from "wouter"

export default function BlogPostPage() {
  const [match, params] = useRoute("/blog/:slug");

  if (!match) return null;

  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <BlogArticle slug={params.slug} />
      </main>
      <Footer />
    </>
  )
}
