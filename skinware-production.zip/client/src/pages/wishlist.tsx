import { Link } from "wouter"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { useWishlist } from "@/components/wishlist-provider"
import { useCart } from "@/components/cart-provider"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"
import { Heart, ShoppingBag, ArrowLeft } from "@/components/icons"
import { toast } from "sonner"

export default function WishlistPage() {
  const { items, removeItem } = useWishlist()
  const { addItem } = useCart()

  const handleAddToCart = (item: any) => {
    addItem({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      quantity: 1,
    })
    toast.success(`${item.name} añadido al carrito`)
  }

  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <div className="container mx-auto px-6 py-12">
          <AnimatedSection className="mb-8">
            <div className="flex items-center gap-4 mb-8">
              <Link href="/productos" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <ArrowLeft className="w-4 h-4" />
                Volver
              </Link>
            </div>
            
            <h1 className="font-serif text-4xl text-foreground mb-2">Mi Lista de Deseos</h1>
            <p className="text-muted-foreground">
              {items.length} {items.length === 1 ? "producto" : "productos"} guardado{items.length !== 1 ? "s" : ""}
            </p>
          </AnimatedSection>

          {items.length === 0 ? (
            <AnimatedSection direction="up" className="py-20 text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-muted mb-6">
                <Heart className="w-10 h-10 text-muted-foreground" />
              </div>
              <h2 className="font-serif text-2xl text-foreground mb-4">Tu lista está vacía</h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                Agrega productos a tu lista de deseos para tenerlos guardados y poder comprarlos después.
              </p>
              <Button asChild>
                <Link href="/productos">Explorar productos</Link>
              </Button>
            </AnimatedSection>
          ) : (
            <AnimatedSection direction="up" className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {items.map((item, index) => (
                <div 
                  key={item.id} 
                  className="group bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 hover:shadow-xl transition-all duration-300 flex flex-col hover:-translate-y-1 animate-in fade-in slide-in-from-bottom-4"
                  style={{animationDelay: `${index * 100}ms`}}
                >
                  <div className="aspect-square overflow-hidden bg-gradient-to-br from-muted to-muted/50 relative">
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    />
                    {/* Overlay on hover */}
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300" />
                    
                    <button
                      onClick={() => removeItem(item.id)}
                      className="absolute top-3 right-3 p-2.5 rounded-full bg-destructive/90 text-white hover:bg-destructive hover:scale-110 transition-all duration-200 shadow-lg hover:shadow-xl"
                      aria-label="Remover de lista"
                    >
                      <Heart className="w-5 h-5 fill-white" />
                    </button>
                  </div>
                  <div className="p-4 flex flex-col flex-1">
                    <p className="text-xs text-muted-foreground mb-2 capitalize font-semibold">{item.category}</p>
                    <h3 className="font-medium text-foreground mb-2 line-clamp-2 flex-1 group-hover:text-primary transition-colors">{item.name}</h3>
                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50">
                      <p className="font-serif text-lg text-primary font-bold">{item.price}€</p>
                      <Button
                        size="sm"
                        onClick={() => handleAddToCart(item)}
                        className="gap-2 group/btn hover:scale-105 transition-transform"
                      >
                        <ShoppingBag className="w-4 h-4 group-hover/btn:scale-110 transition-transform" />
                        Agregar
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </AnimatedSection>
          )}
        </div>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
