import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { useState } from "react"
import { Button } from "@/components/ui/button"

const products = [
  { id: 1, name: "Sérum Vitamina C", price: 58, rating: 4.9, benefits: ["Luminosidad", "Antioxidante", "Firmeza"] },
  { id: 2, name: "Sérum Retinol", price: 62, rating: 4.6, benefits: ["Anti-edad", "Renovación", "Firmeza"] },
  { id: 3, name: "Sérum Ácido Hialurónico", price: 48, rating: 4.7, benefits: ["Hidratación", "Elasticidad", "Volumen"] },
]

export default function ComparatorPage() {
  const [selected, setSelected] = useState<number[]>([])

  return (
    <>
      <Navbar />
      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-5xl text-foreground mb-4">Comparador de Productos</h1>
              <p className="text-lg text-muted-foreground">Elige 2-3 productos para comparar</p>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {products.map((prod) => (
                <AnimatedSection key={prod.id}>
                  <button
                    onClick={() => {
                      if (selected.includes(prod.id)) {
                        setSelected(selected.filter(s => s !== prod.id))
                      } else if (selected.length < 3) {
                        setSelected([...selected, prod.id])
                      }
                    }}
                    className={`w-full p-6 rounded-2xl border-2 transition-all ${selected.includes(prod.id) ? 'border-primary bg-primary/5' : 'border-border bg-card'}`}
                  >
                    <h3 className="font-serif text-xl text-foreground mb-2">{prod.name}</h3>
                    <p className="text-primary font-bold mb-3">{prod.price}€</p>
                    <div className="flex items-center gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <span key={i} className={i < Math.floor(prod.rating) ? "text-primary" : "text-muted"}>★</span>
                      ))}
                    </div>
                    <div className="text-sm text-muted-foreground">{prod.benefits.join(", ")}</div>
                  </button>
                </AnimatedSection>
              ))}
            </div>

            {selected.length > 0 && (
              <AnimatedSection direction="up" className="bg-card border border-border rounded-2xl p-8">
                <h2 className="font-serif text-2xl text-foreground mb-6">Comparación</h2>
                <div className="space-y-4">
                  {selected.map(id => {
                    const prod = products.find(p => p.id === id)
                    return (
                      <div key={id} className="flex justify-between items-center p-4 border border-border rounded-lg">
                        <div className="text-left">
                          <p className="font-medium text-foreground">{prod?.name}</p>
                          <p className="text-sm text-muted-foreground">{prod?.benefits.join(" • ")}</p>
                        </div>
                        <p className="text-primary font-bold">{prod?.price}€</p>
                      </div>
                    )
                  })}
                </div>
                <Button className="w-full mt-6 rounded-full bg-primary text-primary-foreground">Agregar a carrito</Button>
              </AnimatedSection>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
