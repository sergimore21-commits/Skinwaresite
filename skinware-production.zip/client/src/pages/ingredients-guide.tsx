import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"

const ingredients = [
  { name: "Vitamina C", benefits: "Antioxidante, luminosidad, firmeza", skinType: "Todos" },
  { name: "Ácido Hialurónico", benefits: "Hidratación profunda, elasticidad", skinType: "Deshidratada" },
  { name: "Retinol", benefits: "Renovación celular, anti-edad", skinType: "Madura" },
  { name: "Niacinamida", benefits: "Control de sebo, poros, acné", skinType: "Grasa" },
  { name: "Centella Asiática", benefits: "Calmante, antiinflamatorio", skinType: "Sensible" },
  { name: "Ácido Salicílico", benefits: "Exfoliación, acné, poros", skinType: "Grasa/Acneica" },
]

export default function IngredientsGuidePage() {
  return (
    <>
      <Navbar />
      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-5xl text-foreground mb-4">Guía de Ingredientes</h1>
              <p className="text-lg text-muted-foreground">Conoce qué hace cada ingrediente en tu piel</p>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 gap-6">
              {ingredients.map((ing, i) => (
                <AnimatedSection key={i} delay={i * 50}>
                  <div className="bg-card border border-border rounded-2xl p-6 hover:shadow-lg transition-all">
                    <h3 className="font-serif text-xl text-foreground mb-2">{ing.name}</h3>
                    <div className="space-y-3">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Beneficios</p>
                        <p className="text-sm text-foreground">{ing.benefits}</p>
                      </div>
                      <div className="flex items-center gap-2 pt-2 border-t border-border">
                        <span className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">{ing.skinType}</span>
                      </div>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
