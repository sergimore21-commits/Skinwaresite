import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { StarIcon } from "@/components/icons"
import avatar1 from "@assets/generated_images/female_customer_testimonial_avatar_1.png"
import avatar2 from "@assets/generated_images/male_customer_testimonial_avatar_2.png"
import avatar3 from "@assets/generated_images/female_customer_testimonial_avatar_3.png"

const testimonials = [
  {
    id: 1,
    name: "María López",
    role: "Barcelona",
    avatar: avatar1,
    text: "Mi piel mejoró en 2 semanas. Los productos Skinware son exactamente lo que mi piel necesitaba. El diagnóstico de IA fue sorprendentemente preciso.",
    rating: 5,
  },
  {
    id: 2,
    name: "Carlos Martín",
    role: "Madrid",
    avatar: avatar2,
    text: "Después de años probando diferentes marcas, finalmente encontré algo que funciona. La personalización realmente marca la diferencia. Altamente recomendado.",
    rating: 5,
  },
  {
    id: 3,
    name: "Emma García",
    role: "Valencia",
    avatar: avatar3,
    text: "La calidad de los productos es excepcional y el servicio al cliente es impecable. Skinware no es solo una marca, es una experiencia completa.",
    rating: 5,
  },
  {
    id: 4,
    name: "David Rodríguez",
    role: "Sevilla",
    avatar: avatar2,
    text: "El mejor cuidado de piel que he probado. Los ingredientes son naturales y efectivos. Mi piel nunca se ha visto mejor.",
    rating: 5,
  },
  {
    id: 5,
    name: "Laura Fernández",
    role: "Bilbao",
    avatar: avatar1,
    text: "Increíble. El acné ha desaparecido casi completamente. Skinware cambió mi vida. No puedo imaginar usar otra marca.",
    rating: 5,
  },
  {
    id: 6,
    name: "Pedro Sánchez",
    role: "Málaga",
    avatar: avatar3,
    text: "La combinación de tecnología e ingredientes naturales es perfecta. Mis resultados hablan por sí solos. Skinware es el futuro del skincare.",
    rating: 5,
  },
]

export default function TestimonialsPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-b from-secondary/20 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="max-w-3xl mx-auto text-center">
              <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-6">
                Testimonios
              </span>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 text-balance">
                Lo que nuestros clientes dicen
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Miles de personas confían en Skinware para cuidar su piel. Descubre sus historias de transformación.
              </p>
            </AnimatedSection>
          </div>
        </section>

        {/* Testimonials Grid */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {testimonials.map((testimonial, index) => (
                <AnimatedSection key={testimonial.id} delay={index * 100}>
                  <div className="bg-card border border-border rounded-2xl p-8 h-full flex flex-col hover:shadow-lg transition-shadow">
                    {/* Rating */}
                    <div className="flex gap-1 mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <StarIcon key={i} className="w-4 h-4 fill-primary text-primary" />
                      ))}
                    </div>

                    {/* Quote */}
                    <p className="text-muted-foreground mb-6 flex-grow italic leading-relaxed">
                      "{testimonial.text}"
                    </p>

                    {/* Author */}
                    <div className="flex items-center gap-3 pt-4 border-t border-border">
                      <img
                        src={testimonial.avatar}
                        alt={testimonial.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <p className="font-medium text-foreground text-sm">{testimonial.name}</p>
                        <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                      </div>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-muted">
          <div className="container mx-auto px-6">
            <AnimatedSection className="max-w-2xl mx-auto text-center">
              <h2 className="font-serif text-3xl md:text-4xl text-foreground mb-4">
                ¿Listo para tu transformación?
              </h2>
              <p className="text-muted-foreground mb-8">
                Únete a cientos de clientes satisfechos que ya están viendo resultados con Skinware.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a
                  href="/diagnostico"
                  className="px-8 py-3 bg-primary text-primary-foreground rounded-full hover:bg-primary/90 transition-colors font-medium"
                >
                  Inicia tu diagnóstico
                </a>
                <a
                  href="/productos"
                  className="px-8 py-3 border border-border rounded-full hover:border-primary hover:bg-primary/5 transition-colors font-medium"
                >
                  Descubre productos
                </a>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
