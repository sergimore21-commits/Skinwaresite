import type React from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { MapPinIcon, MailIcon, PhoneIcon, ClockIcon } from "@/components/icons"
import { useState } from "react"

export default function ContactoPage() {
  const [formState, setFormState] = useState({ name: "", email: "", message: "" })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const validateEmail = (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const errors = []
    if (!formState.name.trim()) errors.push("El nombre es requerido")
    if (!formState.email.trim()) errors.push("El email es requerido")
    if (formState.email && !validateEmail(formState.email)) errors.push("Email inválido")
    if (!formState.message.trim()) errors.push("El mensaje es requerido")
    if (formState.message.trim().length < 10) errors.push("El mensaje debe tener al menos 10 caracteres")

    if (errors.length > 0) {
      alert("Por favor completa correctamente:\n• " + errors.join("\n• "))
      return
    }

    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsSubmitting(false)
    setIsSubmitted(true)
    setFormState({ name: "", email: "", message: "" })
  }

  return (
    <>
      <Navbar />
      <main className="pt-20">
        {/* Hero Section - Animated */}
        <section className="py-24 bg-gradient-to-b from-secondary/20 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="max-w-3xl mx-auto text-center">
              <span className="inline-block px-4 py-2 rounded-full bg-secondary text-secondary-foreground text-xs font-medium tracking-wider uppercase mb-6">
                Contacto
              </span>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 text-balance">
                Hablemos de tu piel
              </h1>
              <p className="text-lg text-muted-foreground text-pretty">
                Estamos aquí para ayudarte a descubrir los productos perfectos para ti. Contáctanos y nuestro equipo te
                responderá lo antes posible.
              </p>
            </AnimatedSection>
          </div>
        </section>

        {/* Contact Section - Animated form and info */}
        <section className="py-20">
          <div className="container mx-auto px-6">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <AnimatedSection direction="left">
                <div className="bg-card p-8 md:p-10 rounded-3xl border border-border shadow-lg">
                  <h2 className="font-serif text-2xl md:text-3xl text-foreground mb-6">Envíanos un mensaje</h2>

                  {isSubmitted ? (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                        <MailIcon className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="font-serif text-xl text-foreground mb-2">¡Mensaje enviado!</h3>
                      <p className="text-muted-foreground">Gracias por contactarnos. Te responderemos pronto.</p>
                      <Button onClick={() => setIsSubmitted(false)} variant="outline" className="mt-6 rounded-full">
                        Enviar otro mensaje
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="name" className="text-foreground">
                          Nombre
                        </Label>
                        <Input
                          id="name"
                          value={formState.name}
                          onChange={(e) => setFormState((prev) => ({ ...prev, name: e.target.value }))}
                          placeholder="Tu nombre"
                          required
                          className="rounded-xl bg-muted border-0 focus-visible:ring-primary"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-foreground">
                          Email
                        </Label>
                        <Input
                          id="email"
                          type="email"
                          value={formState.email}
                          onChange={(e) => setFormState((prev) => ({ ...prev, email: e.target.value }))}
                          placeholder="tu@email.com"
                          required
                          className="rounded-xl bg-muted border-0 focus-visible:ring-primary"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="message" className="text-foreground">
                          Mensaje
                        </Label>
                        <Textarea
                          id="message"
                          value={formState.message}
                          onChange={(e) => setFormState((prev) => ({ ...prev, message: e.target.value }))}
                          placeholder="¿En qué podemos ayudarte?"
                          required
                          rows={5}
                          className="rounded-xl bg-muted border-0 focus-visible:ring-primary resize-none"
                        />
                      </div>

                      <Button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full rounded-full bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        {isSubmitting ? "Enviando..." : "Enviar mensaje"}
                      </Button>
                    </form>
                  )}
                </div>
              </AnimatedSection>

              {/* Contact Info & Map */}
              <div className="space-y-8">
                {/* Contact Details */}
                <AnimatedSection direction="right" delay={100}>
                  <div className="bg-muted p-8 rounded-3xl">
                    <h3 className="font-serif text-xl text-foreground mb-6">Información de contacto</h3>
                    <div className="space-y-6">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                          <MapPinIcon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">Ubicación</p>
                          <p className="text-sm text-muted-foreground">Tarragona, España</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                          <MailIcon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">Email</p>
                          <a
                            href="mailto:info@skinware.es"
                            className="text-sm text-muted-foreground hover:text-primary transition-colors"
                          >
                            info@skinware.es
                          </a>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                          <PhoneIcon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">Teléfono</p>
                          <a
                            href="tel:+34977258430"
                            className="text-sm text-muted-foreground hover:text-primary transition-colors"
                          >
                            +34 977 258 430
                          </a>
                        </div>
                      </div>

                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                          <ClockIcon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">Horario</p>
                          <p className="text-sm text-muted-foreground">Lun - Vie: 9:00 - 18:00</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </AnimatedSection>

                {/* Map */}
                <AnimatedSection direction="right" delay={200}>
                  <div className="aspect-[4/3] rounded-3xl overflow-hidden border border-border">
                    <iframe
                      src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d24236.09363522184!2d1.2289931!3d41.1188827!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a3fc1eb04f0875%3A0xe2f8f7f8e4e4e4e4!2sTarragona!5e0!3m2!1ses!2ses!4v1700000000000!5m2!1ses!2ses"
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                      title="Ubicación de Skinware en Tarragona"
                      className="grayscale contrast-110 hover:grayscale-0 transition-all duration-500"
                    />
                  </div>
                </AnimatedSection>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
