import { useState } from "react"
import { Link, useLocation } from "wouter"
import { Button } from "@/components/ui/button"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { EyeIcon, EyeOffIcon, CircleIcon, CheckIcon } from "lucide-react"

const AppleLogo = () => (
  <img src="/apple-logo.png" alt="Apple" className="w-5 h-5 mr-2 inline" />
)

export default function RegisterPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [, navigate] = useLocation()

  const passwordsMatch = password === confirmPassword && password.length > 0
  const isFormValid =
    email &&
    password &&
    confirmPassword &&
    firstName &&
    lastName &&
    passwordsMatch &&
    password.length >= 8

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!isFormValid) return

    setIsSubmitting(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setSubmitted(true)
    setIsSubmitting(false)

    setTimeout(() => {
      navigate("/")
    }, 2000)
  }

  const passwordRequirements = [
    { met: password.length >= 8, label: "Mínimo 8 caracteres" },
    { met: /[A-Z]/.test(password), label: "Una letra mayúscula" },
    { met: /[0-9]/.test(password), label: "Un número" },
    { met: /[!@#$%^&*]/.test(password), label: "Un símbolo especial" },
  ]

  if (submitted) {
    return (
      <>
        <Navbar />
        <main className="min-h-screen bg-gradient-to-b from-background via-muted/20 to-background pt-24 pb-16 px-6">
          <div className="container mx-auto max-w-md">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 mb-6 animate-in fade-in zoom-in duration-500">
                <CheckIcon className="w-8 h-8 text-primary" />
              </div>
              <h1 className="font-serif text-4xl font-bold text-foreground mb-4 animate-in fade-in slide-in-from-bottom-4 duration-700">
                ¡Bienvenida a Skinware!
              </h1>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
                Tu cuenta ha sido creada exitosamente. Estamos preparando tu experiencia personalizada.
              </p>
              <div className="space-y-3 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
                <p className="text-sm text-muted-foreground">Redireccionando en unos momentos...</p>
                <Button
                  asChild
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-full py-6 font-semibold hover:shadow-lg transition-all duration-300"
                >
                  <Link href="/">Ir a Inicio</Link>
                </Button>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </>
    )
  }

  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-gradient-to-b from-background via-muted/20 to-background pt-24 pb-16">
        <div className="container mx-auto max-w-md px-6">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="font-serif text-4xl font-bold text-foreground mb-3">Crear Cuenta</h1>
            <p className="text-muted-foreground text-lg">
              Únete a Skinware y descubre tu rutina personalizada con IA
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Nombre y Apellido */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Nombre</label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  placeholder="María"
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300"
                  required
                  data-testid="input-firstName"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">Apellido</label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  placeholder="García"
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300"
                  required
                  data-testid="input-lastName"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@email.com"
                className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300"
                required
                data-testid="input-email"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Contraseña</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Crea una contraseña segura"
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300 pr-10"
                  required
                  data-testid="input-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                >
                  {showPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Password Requirements */}
            {password && (
              <div className="p-4 rounded-lg bg-muted/50 border border-border/30 space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <p className="text-xs font-semibold text-foreground mb-3">Requisitos de seguridad:</p>
                <div className="space-y-2">
                  {passwordRequirements.map((req, idx) => (
                    <div
                      key={idx}
                      className={`flex items-center gap-2 text-xs transition-all duration-300 ${
                        req.met ? "text-primary" : "text-muted-foreground"
                      }`}
                    >
                      <div
                        className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                          req.met ? "bg-primary border-primary" : "border-muted-foreground"
                        }`}
                      >
                        {req.met && <span className="text-white text-xs">✓</span>}
                      </div>
                      {req.label}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Confirm Password */}
            <div>
              <label className="block text-sm font-semibold text-foreground mb-2">Confirmar Contraseña</label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repite tu contraseña"
                  className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all duration-300 pr-10"
                  required
                  data-testid="input-confirmPassword"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showConfirmPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                >
                  {showConfirmPassword ? <EyeOffIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
              </div>
              {confirmPassword && !passwordsMatch && (
                <p className="text-xs text-destructive mt-2">Las contraseñas no coinciden</p>
              )}
              {confirmPassword && passwordsMatch && (
                <p className="text-xs text-primary mt-2 flex items-center gap-1">
                  <span>✓</span> Las contraseñas coinciden
                </p>
              )}
            </div>

            {/* Terms */}
            <div className="flex items-start gap-3">
              <input
                type="checkbox"
                id="terms"
                required
                className="mt-1 w-5 h-5 rounded border-border bg-background text-primary cursor-pointer"
                data-testid="checkbox-terms"
              />
              <label htmlFor="terms" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                Acepto los{" "}
                <Link href="/terminos" className="text-primary hover:text-primary/80 underline">
                  Términos de Servicio
                </Link>
                ,{" "}
                <Link href="/privacidad" className="text-primary hover:text-primary/80 underline">
                  Política de Privacidad
                </Link>{" "}
                y la{" "}
                <Link href="/cookies" className="text-primary hover:text-primary/80 underline">
                  Política de Cookies
                </Link>
              </label>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={!isFormValid || isSubmitting}
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg py-3 font-semibold hover:shadow-lg transition-all duration-300 mt-8"
              data-testid="button-register"
            >
              {isSubmitting ? "Creando cuenta..." : "Crear Cuenta"}
            </Button>
          </form>

          {/* Divider */}
          <div className="relative my-8">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border/30"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-background text-muted-foreground">O crea tu cuenta con</span>
            </div>
          </div>

          {/* Social Signup */}
          <div className="grid grid-cols-2 gap-2 mb-8">
            <Button
              variant="outline"
              className="rounded-lg py-3 font-semibold border border-border hover:bg-muted transition-all duration-300 text-sm"
              type="button"
              title="Crear cuenta con Google"
            >
              <span className="mr-1">G</span> Google
            </Button>
            <Button
              variant="outline"
              className="rounded-lg py-3 font-semibold border border-border hover:bg-muted transition-all duration-300 text-sm"
              type="button"
              title="Crear cuenta con Apple"
            >
              <AppleLogo /> Apple
            </Button>
          </div>

          {/* Login Link */}
          <p className="text-center text-sm text-muted-foreground mt-8">
            ¿Ya tienes cuenta?{" "}
            <Link href="/login" className="text-primary hover:text-primary/80 font-semibold underline">
              Inicia sesión
            </Link>
          </p>

          {/* Trust Badges */}
          <div className="mt-12 pt-8 border-t border-border/30">
            <p className="text-center text-xs text-muted-foreground mb-4">Tu seguridad es nuestra prioridad</p>
            <div className="flex justify-center items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>🔒</span>
                <span>SSL Encriptado</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>✓</span>
                <span>RGPD Compliant</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>✓</span>
                <span>PCI DSS L1</span>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
