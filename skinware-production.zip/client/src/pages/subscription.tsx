import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"

export default function SubscriptionPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20">
        <section className="py-24 bg-gradient-to-b from-primary/10 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection className="text-center max-w-3xl mx-auto">
              <h1 className="font-serif text-5xl text-foreground mb-4">Rutinas Personalizadas</h1>
              <p className="text-lg text-muted-foreground">Recibe tu kit mensual personalizado automáticamente</p>
            </AnimatedSection>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-6 max-w-2xl">
            <AnimatedSection direction="up" className="bg-card border border-border rounded-2xl p-8 space-y-6">
              <div>
                <h2 className="font-serif text-2xl text-foreground mb-4">¿Cómo funciona?</h2>
                <ol className="space-y-4">
                  {[
                    "Completa tu diagnóstico personalizado",
                    "Recibe un kit mensual con los productos que tu piel necesita",
                    "Usa y da feedback sobre los resultados",
                    "Tu rutina se adapta cada mes según tus comentarios"
                  ].map((step, i) => (
                    <li key={i} className="flex gap-4">
                      <span className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-bold">{i + 1}</span>
                      <p className="text-foreground pt-1">{step}</p>
                    </li>
                  ))}
                </ol>
              </div>

              <div className="bg-primary/5 p-6 rounded-xl">
                <h3 className="font-serif text-xl text-foreground mb-3">Beneficios</h3>
                <ul className="space-y-2">
                  {[
                    "20% de descuento en cada kit",
                    "Envío gratis",
                    "Personalización mensual",
                    "Acceso prioritario a nuevos productos",
                    "Cancelación sin compromiso"
                  ].map((benefit, i) => (
                    <li key={i} className="flex gap-2 text-sm">
                      <span className="text-primary">✓</span>
                      <span className="text-foreground">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <Button className="w-full rounded-full h-12 bg-primary text-primary-foreground hover:bg-primary/90">
                Comenzar suscripción
              </Button>
            </AnimatedSection>
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
