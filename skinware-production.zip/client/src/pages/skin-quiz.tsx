import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { AnimatedSection } from "@/components/animated-section"
import { Button } from "@/components/ui/button"
import { useState } from "react"

const questions = [
  { q: "¿Cómo es tu piel?", options: ["Grasa", "Seca", "Mixta", "Normal"] },
  { q: "¿Cuál es tu mayor preocupación?", options: ["Acné", "Arrugas", "Manchas", "Sensibilidad"] },
  { q: "¿Tu piel es sensible?", options: ["Muy sensible", "Poco sensible", "Normal", "Resistente"] },
]

export default function SkinQuizPage() {
  const [current, setCurrent] = useState(0)
  const [answers, setAnswers] = useState<string[]>([])

  const handleAnswer = (answer: string) => {
    const newAnswers = [...answers, answer]
    setAnswers(newAnswers)
    setCurrent(current + 1)
  }

  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen flex items-center">
        <section className="w-full py-20">
          <div className="container mx-auto px-6 max-w-2xl">
            {current < questions.length ? (
              <AnimatedSection className="bg-card border border-border rounded-2xl p-8">
                <div className="mb-6">
                  <p className="text-sm text-primary font-medium">Pregunta {current + 1} de {questions.length}</p>
                  <div className="h-2 bg-muted rounded-full mt-2">
                    <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${((current + 1) / questions.length) * 100}%` }}></div>
                  </div>
                </div>
                <h2 className="font-serif text-3xl text-foreground mb-6">{questions[current].q}</h2>
                <div className="space-y-3">
                  {questions[current].options.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => handleAnswer(opt)}
                      className="w-full p-4 text-left border border-border rounded-lg hover:border-primary hover:bg-primary/5 transition-all font-medium"
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </AnimatedSection>
            ) : (
              <AnimatedSection direction="up" className="text-center bg-card border border-border rounded-2xl p-8">
                <h2 className="font-serif text-3xl text-foreground mb-4">¡Test completado!</h2>
                <p className="text-muted-foreground mb-6">Basado en tus respuestas: {answers.join(", ")}</p>
                <Button className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90" asChild>
                  <a href="/diagnostico">Realizar diagnóstico completo</a>
                </Button>
              </AnimatedSection>
            )}
          </div>
        </section>
      </main>
      <Footer />
      <Chatbot />
    </>
  )
}
