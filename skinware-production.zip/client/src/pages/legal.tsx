import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AnimatedSection } from "@/components/animated-section"

export default function LegalPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen">
        <div className="container mx-auto px-6 py-16">
          <AnimatedSection direction="up" className="max-w-3xl mx-auto">
            <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-8">Responsable Legal</h1>

            <div className="prose prose-lg max-w-none text-muted-foreground space-y-6">
              <p className="text-sm text-muted-foreground">Última actualización: 28 de noviembre de 2024</p>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Identificación de la Empresa</h2>
                <div className="bg-card border border-border rounded-lg p-6 space-y-3">
                  <p>
                    <strong className="text-foreground">Denominación Social:</strong>
                    <br />
                    Skinware Cosmetics SL
                  </p>
                  <p>
                    <strong className="text-foreground">CIF:</strong>
                    <br />
                    B12345678
                  </p>
                  <p>
                    <strong className="text-foreground">Domicilio Social:</strong>
                    <br />
                    Av. Martí i Franquès, 12<br />
                    43007 Tarragona, España
                  </p>
                  <p>
                    <strong className="text-foreground">Teléfono:</strong>
                    <br />
                    +34 977 258 430
                  </p>
                  <p>
                    <strong className="text-foreground">Email Legal:</strong>
                    <br />
                    legal@skinware.es
                  </p>
                </div>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Administración Responsable</h2>
                <div className="space-y-4">
                  <div className="bg-card border border-border rounded-lg p-6">
                    <p className="font-semibold text-foreground mb-1">Director General</p>
                    <p className="text-muted-foreground">Lucio Machado</p>
                    <p className="text-xs text-muted-foreground mt-2">Email: lucio@skinware.com</p>
                  </div>
                  <div className="bg-card border border-border rounded-lg p-6">
                    <p className="font-semibold text-foreground mb-1">Responsable Legal</p>
                    <p className="text-muted-foreground">Sergi Moreno</p>
                    <p className="text-xs text-muted-foreground mt-2">Email: legal@skinware.es</p>
                  </div>
                  <div className="bg-card border border-border rounded-lg p-6">
                    <p className="font-semibold text-foreground mb-1">Responsable de Protección de Datos (DPO)</p>
                    <p className="text-muted-foreground">Equipo de Cumplimiento Normativo</p>
                    <p className="text-xs text-muted-foreground mt-2">Email: dpd@skinware.es</p>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Registro Mercantil</h2>
                <p>
                  Inscrita en el Registro Mercantil de Tarragona, Tomo XXX, Folio 45, Hoja T-123456, con fecha de inscripción: 15 de enero de 2023.
                </p>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Actividad de la Empresa</h2>
                <p>
                  Skinware Cosmetics SL es una empresa dedicada a:
                </p>
                <ul className="list-disc pl-6 space-y-2 mt-4">
                  <li>Diseño, formulación y comercialización de productos de cosmética personalizada</li>
                  <li>Prestación de servicios de diagnóstico de piel mediante inteligencia artificial</li>
                  <li>Venta de productos de skincare y cosmética online</li>
                  <li>Investigación y desarrollo en biotecnología cosmética</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Licencias y Autorizaciones</h2>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Licencia de actividad comercial de Tarragona</li>
                  <li>Registro como fabricante de cosmética según el Reglamento (CE) 1223/2009</li>
                  <li>Cumplimiento del Reglamento (CE) 1907/2006 (REACH)</li>
                  <li>Certificación dermatológica de productos</li>
                </ul>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Política de Reclamaciones</h2>
                <p>
                  Para presentar una reclamación o queja sobre nuestros productos o servicios:
                </p>
                <div className="bg-card border border-border rounded-lg p-6 mt-4">
                  <p className="text-sm text-muted-foreground">
                    Envía un email a <strong>legal@skinware.es</strong> con:
                  </p>
                  <ul className="list-disc pl-6 space-y-2 mt-3 text-sm text-muted-foreground">
                    <li>Tu nombre completo y datos de contacto</li>
                    <li>Número de pedido (si aplica)</li>
                    <li>Descripción detallada de la queja</li>
                    <li>Documentación de apoyo (fotografías, recibos, etc.)</li>
                  </ul>
                  <p className="text-sm text-muted-foreground mt-3">
                    Procesaremos tu reclamación en 10 días hábiles.
                  </p>
                </div>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Datos de Contacto</h2>
                <div className="space-y-3 text-sm">
                  <p>
                    <strong className="text-foreground">Contacto General:</strong><br />
                    info@skinware.es | +34 977 258 430
                  </p>
                  <p>
                    <strong className="text-foreground">Contacto Legal:</strong><br />
                    legal@skinware.es
                  </p>
                  <p>
                    <strong className="text-foreground">Responsable de Datos (RGPD):</strong><br />
                    dpd@skinware.es
                  </p>
                  <p>
                    <strong className="text-foreground">Reclamaciones:</strong><br />
                    legal@skinware.es
                  </p>
                </div>
              </section>

              <section>
                <h2 className="font-serif text-2xl text-foreground mt-8 mb-4">Documentos Legales Relacionados</h2>
                <ul className="list-disc pl-6 space-y-2">
                  <li>
                    <a href="/privacidad" className="text-primary hover:text-primary/80">
                      Política de Privacidad
                    </a>
                  </li>
                  <li>
                    <a href="/terminos" className="text-primary hover:text-primary/80">
                      Términos de Uso
                    </a>
                  </li>
                  <li>
                    <a href="/cookies" className="text-primary hover:text-primary/80">
                      Política de Cookies
                    </a>
                  </li>
                </ul>
              </section>
            </div>
          </AnimatedSection>
        </div>
      </main>
      <Footer />
    </>
  )
}
