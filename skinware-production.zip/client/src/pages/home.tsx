import { useEffect } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Chatbot } from "@/components/chatbot"
import { HeroSection } from "@/components/hero-section"
import { AIDiagnosticBanner } from "@/components/ai-diagnostic-banner"
import { VideoHeroSection } from "@/components/video-hero-section"
import { FeaturedProducts } from "@/components/featured-products"
import { BenefitsSection } from "@/components/benefits-section"
import { ProductBundles } from "@/components/product-bundles"
import { SocialProofSection } from "@/components/social-proof-section"
import { GuaranteeSection } from "@/components/guarantee-section"
import { FAQExpanded } from "@/components/faq-expanded"
import { TrustBarTop } from "@/components/trust-bar-top"
import { BlackFridayBanner } from "@/components/black-friday-banner"
import { SocialProofNotifications } from "@/components/social-proof-notifications"
import { CartCTAFloating } from "@/components/cart-cta-floating"

export default function HomePage() {
  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  return (
    <>
      <Navbar />
      <TrustBarTop />
      <BlackFridayBanner discount={40} productCount={12} />
      <main>
        <HeroSection />
        <AIDiagnosticBanner />
        <VideoHeroSection />
        <FeaturedProducts />
        <ProductBundles />
        <BenefitsSection />
        <SocialProofSection />
        <GuaranteeSection />
        <FAQExpanded />
      </main>
      <Footer />
      <Chatbot />
      <SocialProofNotifications />
      <CartCTAFloating />
    </>
  )
}
