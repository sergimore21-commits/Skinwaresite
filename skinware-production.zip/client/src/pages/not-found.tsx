import { Link } from "wouter"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { AnimatedSection } from "@/components/animated-section"

export default function NotFound() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen flex items-center">
        <section className="w-full py-24 bg-gradient-to-b from-secondary/20 to-background">
          <div className="container mx-auto px-6">
            <AnimatedSection direction="up" className="text-center max-w-2xl mx-auto">
              <div className="text-9xl font-serif text-primary/30 mb-6">404</div>
              <h1 className="font-serif text-4xl md:text-5xl text-foreground mb-4">Página no encontrada</h1>
              <p className="text-lg text-muted-foreground mb-4">
                Parece que la página que buscas no existe o ha sido movida. No te preocupes, aquí te ayudamos a encontrar lo que necesitas.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
                <Button asChild className="rounded-full px-8 h-12 bg-primary text-primary-foreground hover:bg-primary/90">
                  <Link href="/">Volver al inicio</Link>
                </Button>
                <Button asChild variant="outline" className="rounded-full px-8 h-12">
                  <Link href="/productos">Ver productos</Link>
                </Button>
              </div>
            </AnimatedSection>
          </div>
        </section>
      </main>
      <Footer />
    </>
  )
}
