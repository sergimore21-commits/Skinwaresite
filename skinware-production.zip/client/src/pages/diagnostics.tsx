import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { DiagnosticoForm } from "@/components/diagnostico-form"

export default function DiagnosticoPage() {
  return (
    <>
      <Navbar />
      <main className="pt-20 min-h-screen bg-gradient-to-b from-background via-secondary/5 to-background">
        <DiagnosticoForm />
      </main>
      <Footer />
    </>
  )
}
